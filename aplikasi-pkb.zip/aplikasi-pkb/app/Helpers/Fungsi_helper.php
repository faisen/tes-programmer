<?php
	use App\Models\Dapur;
	function webSite(){
		
		$mdl = new Dapur(['table' =>'myapp', 'pk' => 'id_app']);
		$site = $mdl->bagian()->getRow();
		return $site;
    }
	function login(){
		if(session('id_pengguna') == null && session('status_login') == false){
			
           echo "<script>window.location.href='".base_url()."';</script>";
			exit;
       }
	}
	function buatpassword($panjang)
	{
		$karakter= '123456789ABCDFGHIJKLMNPQRSTUVWXYZabcdefhijkmnprstuvwxyzxcvbn';
		$string = '';
			for ($i = 0; $i < $panjang; $i++) {
				$pos = rand(0, strlen($karakter)-1);
				$string .= $karakter{$pos};
		}
		return $string;
	}

	function enkrip($pass, $salt='ver2P1176tspbkl190FsBnABCNDPOWER'){
		
		$str = $pass . $salt;
		return password_hash($str, PASSWORD_DEFAULT);
	}

	function dekrip($pass, $hash, $salt='ver2P1176tspbkl190FsBnABCNDPOWER'){
		
		$str = $pass . $salt;
		return password_verify($str, $hash);
	}

	function kunci($str) {
		$kunci = "ver2P1176";
		$hasil ='';
		for($i=0; $i<strlen($str); $i++){
			$hasil .= $str[$i] . $kunci;
		} 
		return $hasil;
	}
	
	function ambil($str) {
		$CI =& get_instance();
		return $CI->input->post($str, TRUE);
	}
	
 	function encrypt($str) {
		$kunci = "ver2P1176tspbkl190FsBnABCNDPOWERTHErootLockMe";
		$hasil= substr($kunci,0,12).$str.substr($kunci,15,20);
		return $url = str_replace('=','',base64_encode($hasil));
	}
	function decrypt($str) {
		$kunci = 'ver2P1176tspbkl190FsBnABCNDPOWERTHErootLockMe';
		$decode = str_replace(substr($kunci,0,12),'', base64_decode($str));
		return str_replace(substr($decode,-20),'', $decode);
		
	}
	function waktu()
   	{
	   date_default_timezone_set('Asia/Jakarta');
	   return date("Y-m-d H:i:s");
   	}
   
   function tanggal()
   {
	   date_default_timezone_set('Asia/Jakarta');
	   return date("Y-m-d");
   }
   function tgl_indo($tanggal)
       {
		$tl_new = substr($tanggal, 0, 10);
		  date_default_timezone_set('Asia/Jakarta');
            //return substr($tgl, 8, 2).' '.getbln(substr($tgl, 5,2)).' '.substr($tgl, 0, 4);
			$bulan = array (1 =>   'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember',
			0=>'--',
			);
			$split = explode('-', $tl_new);
			if(!empty($split[2])){
				return $split[2] . ' ' . $bulan[ (int)$split[1] ] . ' ' . $split[0];
			}else{
				return "--";
			}
	}
	function rp($x)
    {
	   return number_format($x,0,",",".");
    }
	
	function tgl_indojam($tgl,$pemisah)
    {
		date_default_timezone_set('Asia/Jakarta');
        return substr($tgl, 11,8).' '.$pemisah.' '.substr($tgl, 8, 2).' '.bulan(substr($tgl, 5,2)).' '.substr($tgl, 0, 4);
    }
	
	function SelisihWaktu($tgl)
    {
		date_default_timezone_set('Asia/Jakarta');
        $awal  = new DateTime($tgl);
		$akhir = new DateTime(); // Waktu sekarang
		$diff  = $awal->diff($akhir);
		$text  = "";

		if($diff->s < 60){
			$text = $diff->s . ' detik yang lalu';
		}elseif($diff->s >60){
			$text = $diff->i . ' menit yang lalu';
		}elseif($diff->i >60){
			$text = $diff->h . ' jam yang lalu';
		}elseif($diff->h >24){
			$text = $diff->d . ' hari yang lalu';
		}elseif($diff->d >30){
			$text = $diff->m . ' bulan yang lalu';
		}elseif($diff->m >11){
			$text = $diff->y . ' tahun yang lalu';
		}
		return $text;
    }
	function penyebut($nilai) {
		$nilai = abs($nilai);
		$huruf = array("", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas");
		$temp = "";
		if ($nilai < 12) {
			$temp = " ". $huruf[$nilai];
		} else if ($nilai <20) {
			$temp = penyebut($nilai - 10). " belas";
		} else if ($nilai < 100) {
			$temp = penyebut($nilai/10)." puluh". penyebut($nilai % 10);
		} else if ($nilai < 200) {
			$temp = " seratus" . penyebut($nilai - 100);
		} else if ($nilai < 1000) {
			$temp = penyebut($nilai/100) . " ratus" . penyebut($nilai % 100);
		} else if ($nilai < 2000) {
			$temp = " seribu" . penyebut($nilai - 1000);
		} else if ($nilai < 1000000) {
			$temp = penyebut($nilai/1000) . " ribu" . penyebut($nilai % 1000);
		} else if ($nilai < 1000000000) {
			$temp = penyebut($nilai/1000000) . " juta" . penyebut($nilai % 1000000);
		} else if ($nilai < 1000000000000) {
			$temp = penyebut($nilai/1000000000) . " milyar" . penyebut(fmod($nilai,1000000000));
		} else if ($nilai < 1000000000000000) {
			$temp = penyebut($nilai/1000000000000) . " trilyun" . penyebut(fmod($nilai,1000000000000));
		}     
		return $temp;
	}
 
	function terbilang($nilai) {
		if($nilai<0) {
			$hasil = "minus ". trim(penyebut($nilai));
		} else {
			$hasil = trim(penyebut($nilai));
		}     		
		return $hasil;
	}
	
   	function setSertifikat($id_user, $data){	
		$CI =& get_instance();
		$user = $CI->session->userdata('nama');
		$path = APPPATH .'/sertifikat/crt_' . $id_user . '.key';	
		$file = fopen($path, "w");	
		$isi = base64_encode($id_user).",".$data;
		fwrite($file, $isi);
		fclose($file);
		
	}
	
	function setLogUser($act, $data){	
		$CI =& get_instance();
		$user = $CI->session->userdata('nama');
		$path = APPPATH .'/logs/' . $act .'_'. date('M-Y'). '.txt';	
		$file = fopen($path, "a");	
		$top ="\r\n";
		$top .="------- By : ".$user.", act : ".$act.", date :".date("Y:m:d")." ip_add :".$_SERVER['REMOTE_ADDR']." ---------- \r\n";
		$bottom ="\r\n";
		fwrite($file, $top.json_encode($data, true).$bottom);
		fclose($file);
		
	}
	
	function statusLogin(){
		$CI =& get_instance();
		$data = $CI->session->all_userdata();
		if(count($data) < 4){
			redirect('home/masuk');
			return false;
		}
		return true;
	}
	
	 function dateNow()
   {
	   date_default_timezone_set('Asia/Jakarta');
	   return date("d-m-Y");
   }
   
   function encrypt_url($string) {

    $output = false;
    /*
    * read security.ini file & get encryption_key | iv | encryption_mechanism value for generating encryption code
    */        
    $security       = parse_ini_file("security.ini");
    $secret_key     = $security["encryption_key"];
    $secret_iv      = $security["iv"];
    $encrypt_method = $security["encryption_mechanism"];

    // hash
    $key    = hash("sha256", $secret_key);

    // iv – encrypt method AES-256-CBC expects 16 bytes – else you will get a warning
    $iv     = substr(hash("sha256", $secret_iv), 0, 16);

    //do the encryption given text/string/number
    $result = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
    $output = base64_encode($result);
    return $output;
}



function decrypt_url($string) {

    $output = false;
    /*
    * read security.ini file & get encryption_key | iv | encryption_mechanism value for generating encryption code
    */

    $security       = parse_ini_file("security.ini");
    $secret_key     = $security["encryption_key"];
    $secret_iv      = $security["iv"];
    $encrypt_method = $security["encryption_mechanism"];

    // hash
    $key    = hash("sha256", $secret_key);

    // iv – encrypt method AES-256-CBC expects 16 bytes – else you will get a warning
    $iv = substr(hash("sha256", $secret_iv), 0, 16);

    //do the decryption given text/string/number

    $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    return $output;
}

function bulan($val){
	switch ($val) 
        {
            case '01':
                return 'Januari';
            break;
			case '02':
                return 'Februari';
            break;
			case '03':
                return 'Maret';
            break;
			case '04':
                return 'April';
            break;
        	case '05':
                return 'Mei';
            break;
			case '06':
                return 'Juni';
            break;
			case '07':
                return 'Juli';
            break;
			case '08':
                return 'Agustus';
            break;
			case '09':
                return 'September';
            break;
			case '10':
                return 'Oktober';
            break;
			case '11':
                return 'November';
            break;
			case '12':
                return 'Desember';
            break;
     
		}
}

function posisiPengajuan($val){
	switch ($val) 
        {
            case 0:
                return '<span class="label label-danger">Permohonan Ditolak</span>';
            break;
			case 1:
                return '<span class="label label-warning">Menunggu Verifikasi Operator</span>';
            break;
			case 2:
                return '<span class="label label-warning">Menunggu Verifikasi KASI</span>';
            break;
			case 3:
                return '<span class="label label-warning">Menunggu Verifikasi KABID</span>';
            break;
			case 4:
                return '<span class="label label-warning">Menunggu Verifikasi KABAN</span>';
            break;
			case 5:
                return '<span class="label label-success">Proses selesai</span>';
            break;
			     
		}
}

function statusBerkas($val){
	switch ($val) 
        {
            case 1:
                return '<span class="label label-success">OK</span>';
            break;
			case 2:
                return '<span class="label label-danger">Berkas ditolak</span>';
            break;
		}
}

function rollback($val){
	switch ($val) 
        {
            case 1:
                return 'Operator';
            break;
			case 2:
                return 'KASI';
            break;
			case 3:
                return 'KABID';
            break;
			case 4:
                return 'KABAN';
            break;
			case 5:
                return 'Proses Selesai';
            break;
        	case 0:
                return 'Pemohon';
            break;
     
		}
}

function statusVerifikasi($val){
	switch ($val) 
        {
			case 0:
                return 'Berkas ditolak';
            break;
			case 1:
                return 'Menunggu verifikasi';
            break;
            case 2:
                return 'Diverifikasi oleh Operator';
            break;
			case 3:
                return 'Diverifikasi oleh KASI';
            break;
			case 4:
                return 'Diverifikasi oleh KABID';
            break;
			case 5:
                return 'Proses Selesai';
            break;
        	
     
		}
}

function noUrut($val){
	switch ($val) 
        {
			case 1:
                return 'Pertama';
            break;
			case 2:
                return 'Kedua';
            break;
            case 3:
                return 'Ketiga';
            break;
			case 4:
                return 'Keempat';
            break;
			case 5:
                return 'Kelima';
            break;
			case 6:
                return 'Keenam';
            break;
        	case 7:
                return 'Ketujuh';
            break;
        	case 8:
                return 'Kedelapan';
            break;
        	case 9:
                return 'Kesembilan';
            break;
        	
     
		}
}
function level($val){
	switch ($val) 
        {
			case 0:
                return 'Pegawai biasa';
            break;
			case 1:
                return 'Operator OPD';
            break;
            case 2:
                return 'Pengawas Operator';
            break;
			case 3:
                return 'Operator BKPP';
            break;
			case 4:
                return 'Admin Super BKPP';
            break;
			case 5:
                return 'Apps';
            break;
     
		}
}

//input form function

function dropdown($name,$table,$field,$pk,$alias='',$id=null,$class=null,$kondisi=null,$selected=null,$fungsi=null, $data=null,$tags=null)
	{
		$mdl = new Dapur(['table' =>$table, 'pk' => $pk]);
		$site = $mdl->bagian()->getRow();
		
	   $html = "<select name='".$name."' class='".$class."' id='".$id."' ".$fungsi.">";
			if($data!='')
			{
				foreach ($data as $data_value => $id_data)
				{
					$html .=  "<option value='$id_data'>$data_value</option>";
				}
			}
			if(empty($kondisi))
			{
				$record=$mdl->bagian()->getResult();
			}
			else
			{
				$record=$mdl->tertentu([$pk=>$kondisi], "*", null, 0, '', $pk.' ASC')->getResult();
				//tertentu($where = null, $kolom = '*', $limit = null, $offset = 0, $grup='', $order='')
			}
			
			foreach ($record as $r)
			{
				$html .=  " <option value='".$r->$pk."' ";
				$html .=  $r->$pk==$selected?'selected':'';
				if($alias !=''){
				$html .=  ">".strtoupper($r->$field). " - (".strtoupper($r->$alias).")</option>";
				}
				$html .=  ">".strtoupper($r->$field)."</option>";
			}
				$html .= "</select>";
			return $html;
	}
	
	function getIdOpdByNip()
	{
		$mdl = new Dapur(['table' => 'buku_jabatan', 'pk' => 'id_bk_jabatan']);
		$data = $mdl->berdasarkan('', ['nip'=>session('id_pengguna')])->getRow();
		if(empty($data)){
			return 0;
		}else{
			return $data->id_instansi;
		}
	}