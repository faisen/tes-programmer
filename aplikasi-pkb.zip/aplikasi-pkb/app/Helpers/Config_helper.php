<?php
	use App\Models\Dapur;
	function webSite(){
		
		$mdl = new Dapur(['table' =>'setting', 'pk' => 'id_setting']);
		$site = $mdl->bagian()->getRow();
		return $site;
    }
	function login(){
		if(session('id_pengguna') == null && session('status_login') == false){
			
           echo "<script>window.location.href='".base_url()."';</script>";
			exit;
       }
	}
	
	

}