<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul;?></span></h3>
        <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>
<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
		<form id="formMutasi" method="POST" action="<?= base_url('pajak/input/0')?>">
			
				<fieldset>
				<?php foreach($data as $r):?>
				<div class="col-md-6">
					<label><?= $r?> </label>
					<div class="form-group">
					<input type="text" name="<?= $r?>" id="<?= $r?>" class="form-control" />
					</div>
				</div>
				<?php endforeach;?>
				</fieldset>	
				<br><br>
				<fieldset>
				  <a href="<?= base_url('pajak/getData')?>" class="btn btn-secondary btn-danger" onClick="mundur()">Tutup</a>
				  <input type="submit" name="submit" id="submit" class="btn btn-secondary btn-info" value="Simpan"/>
				</fieldset>
			</form>
		</div>
	</div>
</div>