<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul;?></span></h3>
        <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
			<h3 style="text-align:center;"></h3>
			<hr style="height:1px;border:none;color:#079beb;background-color:#079beb;">
        <p class="demo-button" style="text-align:center;">
			<a href="<?php echo base_url('pajak/input');?>" class="btn btn-primary" target="_blank" ><i class="fa fa-sort-alpha-desc"></i> Tambah Data </a>
		</p>
		
		</div>
	</div>
	<div class="panel loadData" style="display:none;">
		<div class="panel-body">
		<button type="button" class="btn btn-danger btn-xs pull-right" onClick="return tutupMenu();">x</button>
		<hr style="height:1px;border:none;color:#079beb;background-color:#079beb;">
       	<div id="TampilData">
			
        </div>
		
        </div>
	</div>
</div>
<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
			<div class="table-responsive-md" id="daftarPegawai">
			
			<hr style="height:1px;border:none;color:#079beb;background-color:#079beb;">
			<table class="table table-striped bg-dark" data-toggle="table" data-show-refresh="false" data-show-toggle="true" data-show-columns="true" data-search="true"  data-pagination="true" data-sort-name="name" data-sort-order="asc">
				<thead >
					<tr style="align:center;">
						<th>No</th>
						<th>Jenis Kendaran</th>
						<th>Merk</th>
						<th>Tahun Pembuatan</th>
						<th>Nomor Rangka / Nomor Mesin</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody >
				<?php
				$no=1;
				foreach ($data as $r): ?>
				<tr>
					<td data-field="no"><?= $no++?></td>
					<td data-field="no5"><?= $r->jeniskendaraan?></td>
					<td data-field="no6"><?= $r->merkkendaraan?></td>
					<td data-field="no7"><?= $r->tahunbuatan?></td>
					<td data-field="no8"><?= $r->nomorrangka?> / <?= $r->nomormesin?></td>
					<td data-field="no9"><a href="<?= base_url('pajak/rincian/'.encrypt($r->nopol))?>" class="btn btn-info btn-md" >Detail</a> | <a href="<?= base_url('pajak/edit/'.encrypt($r->nopol))?>" class="btn btn-warning btn-md" >Ubah</a> | <a href="<?= base_url('pajak/hapus/'.encrypt($r->nopol))?>" class="btn btn-danger btn-md" >Delete</a></td>
				</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
		</div>
	</div>
</div>