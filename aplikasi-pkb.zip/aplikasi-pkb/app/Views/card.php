<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul?></span></h3>
		<button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>
	<div class="row">
	<div class="col-lg-12">
		<?php foreach($data as $row) : ?>
				<div class="col-md-3">
					<div class="panel panel-default card">
						<div class="panel-heading post-thumb">
							<span class="lnr lnr-menu"></span>
						</div>
						<div class="panel-body post-body">
								<h3 class="post-title">
								<a href="<?php echo base_url('report/opsi/'. encrypt($row->id_layanan));?>"><span class="lnr lnr-enter"></span> <?php echo $row->judul; ?></a>
								</h3>
								<div class="post-author">
									<p class="small"><?php echo $row->deskripsi; ?></p>
								</div>
						</div>
					</div>
				</div>
				<?php endforeach;?>
				
		</div>
	</div>


<div class="modal fade" id="showModalLaporan">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header ">
          <h4 class="modal-title">Tambah </h4>
        </div>
        <div class="modal-body">
			<form id="formApp" method="POST" action="<?php echo base_url('modul/input/')?>">
				<fieldset>
				<?= view_cell('App\Libraries\Widget::getformApp', 'id_layanan=0')?>
										
				</fieldset>	
				<br><br>
				<fieldset>
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="submit" id="btnsave" class="btn btn-secondary btn-info">Simpan</button>
				</fieldset>
			</form>
	  </div>
  </div>
</div>
</div>