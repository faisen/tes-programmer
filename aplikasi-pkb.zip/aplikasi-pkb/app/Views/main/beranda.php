<?php ?>

<!doctype html>
<html lang="en">
<head>
	<title>Aplikasi PKB</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/vendor/linearicons/style.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="<?php echo base_url('public/bank/dialog/dialog.css')?>">
	<link rel="stylesheet" href="<?php echo base_url('public/bank/dialog/sweetalert2.min.css')?>">
	<link rel="stylesheet" href="<?php echo base_url('public/bank/dialog/sweetalert2.css')?>">
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/css/bootstrap-table.css">
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/css/main.css">
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/css/loading_css.css">
	
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/css/select2.min.css">
	
	<style type="text/css">
	.modal-dialog{
		padding-top: 20px;
		border-radius: 0;
	}

	.modal-title{
		color: #4cd2ff;
	}
	input[type=checkbox]
	{
	  /* Double-sized Checkboxes */
	  -ms-transform: scale(2); /* IE */
	  -moz-transform: scale(2); /* FF */
	  -webkit-transform: scale(2); /* Safari and Chrome */
	  -o-transform: scale(2); /* Opera */
	}
	legend {
	background: #0f0f1e;     /* Green */
	color: #9797a6;          /* White */
	margin-bottom: 10px;
	padding: 0.2em 0.5em;
	}
	fieldset {
	border: 1px solid ;
	display: inline-block;
	font-size: 14px;
	padding: 1em 2em;
	width:100%;
	}
	.add_button{ 
	margin-top:10px; 
	margin-left:10px;
	vertical-align: text-bottom;
	}
	.remove_button{ 
		margin-top:10px; 
		margin-left:10px;
		vertical-align: text-bottom;
	}
	
	
</style>

</head>
<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<?= view('main/nav')?>
		<?= view('main/sidebar')?>
		
		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<?= view($content); ?>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
		<!-- END MAIN -->
		
		<div class="clearfix"></div>
		<footer>
			<div class="container-fluid">
				<p></p>
			</div>
		</footer>
	</div>
	  <div id="loadingPage">
            <span class="loaderPage"></span>
            <div class="textLoader">
                <center>
                <b>Please Wait ... </b>
                </center>
            </div>
        </div>
	<script src="<?php echo base_url()?>/public/bank/scripts/jquery/jquery-3.5.1.min.js"></script>
	<script src="<?php echo base_url()?>/public/bank/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url('public/bank/scripts/dialog/sweetalert.min.js')?>"></script>
	<script src="<?php echo base_url('public/bank/scripts/dialog/dialog-active.js')?>"></script>
	<script src="<?php echo base_url()?>/public/bank/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo base_url()?>/public/bank/scripts/klorofil-common.js"></script>
	<script src="<?php echo base_url()?>/public/bank/vendor/bootstrap/js/bootstrap-table.js"></script>
	<script src="<?php echo base_url()?>/public/bank/scripts/select2.js"></script>
	<script src="<?php echo base_url()?>/public/bank/scripts/select2.min.js"></script>
	<script src="<?php echo base_url("public/bank/scripts/". $load_js)?>"></script>
	<script  type="text/javascript">
		load();
	$(document).ready(function(){
		
		var maxField = 10; //Input fields increment limitation
		var addButton = $('.add_button'); //Add button selector
		var wrapper = $('.field_wrapper'); //Input field wrapper
		var fieldHTML = '<div><input type="text" class="form-control" name="nama_penghadap[]" value=""/><a href="javascript:void(0);" class="remove_button" title="Remove field"><span class="lnr lnr-circle-minus">hapus</span></a></div>'; //New input field html 
		var x = 1; //Initial field counter is 1
		$(addButton).click(function(){ //Once add button is clicked
			if(x < maxField){ //Check maximum number of input fields
				x++; //Increment field counter
				$(wrapper).append(fieldHTML); // Add field html
			}
		});
		$(wrapper).on('click', '.remove_button', function(e){ //Once remove button is clicked
			e.preventDefault();
			$(this).parent('div').remove(); //Remove field html
			x--; //Decrement field counter
		});
	});
	function reload(){
		load(500);
		location.reload();
	}
	function load(delay = 300){
		setTimeout(function(){
			$("#loadingPage").remove();
		},delay);
	}
	function mundur(){
		load(500);
		history.go(-1);
	}
	$('.multiSelect').select2({width: '100%'});
	
	function openNewFile(url) {
		popupWindow = window.open(url,'popUpWindow','height=600,width=1000,left=450px,top=200px,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes');
		popUpWindow.onload = function(){
			this.document.title = 'judul';
		}
}
	</script>
	
</body>

</html>