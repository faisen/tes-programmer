<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
											
						<li>
							<a href="#menuutama" data-toggle="collapse" class="collapsed"><i class="lnr lnr-cog"></i> <span>Menu Utama</span><i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="menuutama" class="collapse ">
								<ul class="nav">
									<li><a href="<?php echo base_url('pajak/getData'); ?>" class=""><i class="lnr lnr-file-add"></i> <span>Data PKB</span></a></li>		
									
								</ul>
							</div>
						</li>
						
					</ul>
				</nav>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->