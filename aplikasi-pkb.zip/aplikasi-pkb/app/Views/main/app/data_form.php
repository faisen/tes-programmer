<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $layanan->deskripsi;?></span></h3>
        <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
		<?php if($layanan->admin_only) {?>
		<button class="btn btn-info btn-xs"  data-toggle="modal" data-target="#showModalApp"><span class="lnr lnr-plus-circle"> Tambah data</span></button>
		<?php }else{?>
		<button class="btn btn-info btn-xs" data-toggle="modal" data-target="#showModalApp"><span class="lnr lnr-plus-circle"> Tambah data</span></button>
		<?php }?>
		<table class="table table-striped" data-toggle="table" data-show-refresh="true" data-show-toggle="false" data-show-columns="true" data-search="true"  data-pagination="true" data-sort-name="name" data-sort-order="desc">
			<thead>
				<tr>
					<th>No</th>
					<?php 
					foreach ($form as $field)
					{
					echo ' <th>'. ucwords(str_replace('_', ' ', $field->nama )). '</th>';		
					}?>
					<th>.:.</th>
				</tr>
			</thead>
			<tbody >
			<?php
			$no=0;
			foreach ($isi as $r)
			{
				$no++;
				echo '<tr>';
				echo '<td> ' . $no. '</td>';
				//$field = $r->nama;
				foreach( $form as $row){
					$fl=$row->nama;
					echo '<td> ' . $r->$fl . '</td>';
					
				}
				echo '<td><a class="btn btn-info btn-xs" href="'.base_url().'/modul/formEdit/'.encrypt($id_layanan).'/'.encrypt($r->$pk).')" ><span class="lnr lnr-pencil"></span></a> | <button class="btn btn-danger btn-xs" onclick="hapusDataLayanan('.$id_layanan.','.$r->$pk.')" ><span class="lnr lnr-trash"></span></button></td>';
				echo '</tr>';
			}
			?>
			</tbody>
		</table>
		</div>
	</div>
</div>


<div class="modal fade" id="showModalApp">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header ">
          <h4 class="modal-title">Tambah <?php echo ucwords($layanan->judul)?></h4>
        </div>
        <div class="modal-body">
			<form id="formApp" method="POST" action="<?php echo base_url('modul/input/'.encrypt($layanan->id_layanan))?>">
				<fieldset>
				<?= view_cell('App\Libraries\Widget::getformApp', 'id_layanan='.$layanan->id_layanan.'')?>
										
				</fieldset>	
				<br><br>
				<fieldset>
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="submit" id="btnsave" class="btn btn-secondary btn-info">Simpan</button>
				</fieldset>
			</form>
	  </div>
  </div>
</div>
</div>