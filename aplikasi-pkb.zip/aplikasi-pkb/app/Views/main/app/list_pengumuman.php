
<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul?></span></h3>
       <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
			<div id="reload">
			<button class="btn btn-primary btn-xs" data-toggle="modal" data-target="#modalTambahPengumuman"><span class="lnr lnr-sync"> Buat Pengumuman</span></button>
		<table class="table table-striped" data-toggle="table" data-show-refresh="false" data-show-toggle="false" data-show-columns="false" data-search="true"  data-pagination="true" data-sort-name="name" data-sort-order="desc">
			<thead>
				<tr>
					<th>.</th>
					<th>..</th>
				</tr>
			</thead>
			<tbody >
            <?php $no=1; foreach($data as $row) : ?>
                <tr>
                    <td data-field="no" width="10px"><?php echo $no++?></td>
                    <td>
                    <p><span class="lnr lnr-user"> <?php echo $row->judul;?></span></p>
                    <p><span class="lnr lnr-apartment"> <?php echo $row->isi;?></span></p>
                    <p>Status : <?php echo $row->status ? "tampil" : "disembunyikan";?></p>
                    <a href="<?php echo base_url('modul/modul/'.encrypt('rincian').'/'. encrypt($row->id_pengumuman));?>" class="btn btn-info btn-xs"><span class="lnr lnr-magnifier"> Detail</span></a>
					<button onclick="openNewFile('<?php echo base_url($row->nama_file);?>')"><span class="lnr lnr-enter"></span>Lihat File</button>
                   
                    <button class="btn btn-danger btn-xs" onClick="hapus(<?php echo $row->id_pengumuman?>)"><span class="lnr lnr-trash"> Hapus</span></button>
                    </td>
                    
                </tr>
                <?php endforeach;?>
			</tbody>
		</table>
		</div>
		</div>
	</div>
</div>


<div class="modal fade" id="modalTambahPengumuman">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header ">
          <h4 class="modal-title">Tambah <?php echo ucwords($judul)?></h4>
        </div>
        
        <div class="modal-body">
			<form id="formTambahPengumuman" method="POST" action="<?php echo base_url('Modul/tambahPengumuman/'. encrypt('simpan'));?>">
				<fieldset>
					<div class="col-md-6">
						<label>Judul </label>
						<div class="form-group">
						<input type="text" name="judul" id="judul" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Isi</label>
						<div class="form-group">
						<textarea name="isi" id="isi" class="form-control" > </textarea>
						</div>
					</div>
				 
					<div class="col-md-6" id="fileAwal">
						<label>Sertakan File</label>
						<div class="form-group">
						<input type="file" name="nama_file" id="nama_file" class="form-control" onchange="unggahPersyaratan()" />

						</div>
					</div>
					<div class="col-md-6" id="formFileJadi" style="display:none;">
						<label>Sertakan File</label>
						<div class="form-group">
						<input type="text" name="nama_file_baru" id="nama_file_baru" class="form-control" readonly />
						</div>
					</div>
					<div class="col-md-6">
					<label> Tampilkan Pengumuman </label>
					<div class="form-group">
						<select class="form-control" name="status" id="status" required>
							<option value="1">aktif</option>
							<option value="0">non aktif</option>
						</select>
					</div>
					</div>
				</fieldset>	
				<br><br>
				<fieldset>
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="submit" id="submitPengumuman" class="btn btn-secondary btn-info">Simpan</button>
				</fieldset>
			</form>
        </div>
      </div>
    </div>
  </div>
  

