<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul;?></span></h3>
        <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
		<form id="formEditDataMenu" method="POST" action="<?php echo base_url("menu/simpan/menu/id_menu/".$data->id_menu)?>">
				<fieldset>
					<div class="col-md-6">
						<label>judul </label>
						<div class="form-group">
						<input type="text" name="judul" id="judul" value="<?= $data->judul?>" class="form-control" />
						</div>
					</div>

					<div class="col-md-6">
						<label>icon</label>
						<div class="form-group">
						<input type="text" name="ikon" id="ikon" value="<?= $data->ikon?>" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
					<label> Aktif </label>
					<div class="form-group">
						<select class="form-control" name="aktif" id="sktif" required>
							<option value="<?= $data->aktif?>"><?= $data->aktif?></option>
							<option value="y">aktif</option>
							<option value="n">non aktif</option>
						</select>
					</div>
					</div>
				</fieldset>	
				<br><br>
				<fieldset>
					<input type="hidden" name="tipeInputMenu" id="tipeInputMenu" />
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="button" onClick="saveEditData()" class="btn btn-secondary btn-info">Simpan</button>
				</fieldset>
			</form>
		</div>
	</div>
</div>