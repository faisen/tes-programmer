<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul;?></span></h3>
        <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
		<form id="tambahFormLayanan" method="POST" action="<?php echo base_url($link)?>">
				<fieldset>
					<?= view_cell('App\Libraries\Widget::getformApp', 'id_menu_app='.$id_menu_app.'')?>
				<input type="hidden" name="id_layanan" id="id_layanan" value="<?php echo $id_layanan?>" />
				</fieldset>	
				<br><br>
				<fieldset>
					<input type="hidden" name="id_form" id="id_form" >
					<input type="hidden" name="edit" id="edit" value="0" >
				  <button type="button" class="btn btn-secondary btn-danger" onClick="mundur()">Tutup</button>
				  <button type="submit" id="submitForm" class="btn btn-secondary btn-info">Simpan</button>
				</fieldset>
			</form>
		</div>
	</div>
</div>
