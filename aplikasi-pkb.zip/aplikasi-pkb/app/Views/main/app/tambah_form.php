<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul;?></span></h3>
        <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
		<button class="btn btn-primary btn-xs" onClick="tambahData(<?php echo $id_menu_app;?>)"><span class="lnr lnr-sync"> Tambah</span></button>
		<table class="table table-striped" data-toggle="table" data-show-refresh="true" data-show-toggle="false" data-show-columns="true" data-search="true"  data-pagination="true" data-sort-name="name" data-sort-order="desc">
			<thead>
				<tr>
					<th>#</th>
					<th>nama</th>
					<th>label</th>
					<th>tipe</th>
					<th>.:.</th>
				</tr>
			</thead>
			<tbody>
           <?php $no=1; foreach($data as $row) : ?>
                <tr>
                    <td data-field="no" width="2px"><?= $no++?></td>
                    <td data-field="nama"> <?php echo $row->nama?></td>
                    <td data-field="label"><?php echo $row->label?></td>
                    <td data-field="tipe"><?php echo $row->tipe?></td>
					<td data-field="aksi">
                    <a href="" class="btn btn-info btn-xs"><span class="lnr lnr-magnifier"> Detail</span></a>
                    <button type="button" class="btn btn-primary btn-xs" onClick="editData(<?php echo $row->id_form_app;?>)" ><span class="lnr lnr-pencil"> edit Form</span></button>
                    <button class="btn btn-danger btn-xs" onClick="hapusData(<?php echo $row->id_form_app;?>)"><span class="lnr lnr-trash"> Hapus</span></button>
                    </td>
                    
                </tr>
				<?php endforeach;?>
			</tbody>
		</table>
		</div>
	</div>
</div>

<div class="modal fade" id="modalTambahFormLayanan">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header ">
          <h4 class="modal-title">Tambah <?php echo ucwords($judul)?></h4>
        </div>
        <div class="modal-body">
			<form id="tambahFormLayanan" method="POST" action="">
				<fieldset>
					<div class="col-md-6">
						<label>Nama field </label>
						<div class="form-group">
						<select class="form-control multiSelect" name="nama" id="nama" required>
							<option value="">pilih..</option>
						</select>
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Tipe</label>
						<div class="form-group">
						<select class="form-control multiSelect" name="tipe" id="tipe" required onchange=" if (this.selectedIndex==11)
									{ document.getElementById('disOpsi').style.display = 'inline';}else { 
									document.getElementById('disOpsi').style.display = 'none';  
									};">
							<option value="text">text</option>
							<option value="number">number</option>
							<option value="email">email</option>
							<option value="date">date</option>
							<option value="password">password</option>
							<option value="hidden">hidden</option>
							<option value="select">select</option>
							<option value="textarea">textarea</option>
							<option value="radio">radio</option>
							<option value="checkbox">checkbox</option>
							<option value="file">file</option>
							<option value="dropdown">dropdown</option>
						</select>
						</div>
					</div>
					<div id="disOpsi" style="display:none;">
					<div class="col-md-6">
						<label>Isi fungsi dropdown: </label>
						<div class="form-group">
							<textarea name="dropdown" class="form-control" id="dropdown">ex : dropdown($name,$table,$field,$pk,$id=null,$class=null,$kondisi=null,$selected=null,$data=null,$tags=null)</textarea>
							<p>harus menggunakankan tanda koma</p>
						</div>
					</div>
					</div>
					<div class="col-md-6">
						<label>Label</label>
						<div class="form-group">
						<input type="text" name="label" id="label" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>Kelas</label>
						<div class="form-group">
						<input type="text" name="kelas" id="kelas" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>ID</label>
						<div class="form-group">
						<input type="text" name="id" id="id" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>default value</label>
						<div class="form-group">
						<input type="text" name="def_value" id="def_value" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Konten</label>
						<div class="form-group">
						<textarea class="form-control" name="konten" id="konten"></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label>Pesan</label>
						<div class="form-group">
						<textarea class="form-control" name="pesan" id="pesan"></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label>Izinkan proses latar belakang?</label>
						<div class="form-group">
						<select class="form-control multiSelect" name="under_proces" id="under_proces" required onchange=" if (this.selectedIndex==1)
									{ document.getElementById('namaFungsi').style.display = 'inline';}else { 
									document.getElementById('namaFungsi').style.display = 'none';  
									};">
							<option value="0">Tidak</option>
							<option value="1">Ya</option>
						</select>
						</div>
					</div>
					<div id="namaFungsi" style="display:none;">
					<div class="col-md-6">
						<label>Script fungsi: </label>
						<div class="form-group">
							<textarea name="fungsi" class="form-control" id="fungsi"></textarea>
							<p>Masukan nama fungsi ex: namaFungsi()</p>
						</div>
					</div>
					</div>
					<div class="col-md-6">
						<label>Wajib diisi</label>
						<div class="form-group">
						<select class="form-control" name="wajib" id="wajib" required>
							<option value="1">Ya</option>
							<option value="0">Tidak</option>
						</select>
						</div>
					</div>
					<div class="col-md-6">
					<label> Aktif </label>
					<div class="form-group">
						<select class="form-control" name="aktif" id="aktif" required>
							<option value="y">aktif</option>
							<option value="n">non aktif</option>
						</select>
					</div>
					</div>
				</fieldset>	
				<br><br>
				<fieldset>
					<input type="hidden" name="id_menu_app" id="id_menu_app" value="<?php echo $id_menu_app;?>">
					<input type="hidden" name="id_form" id="id_form" >
					<input type="hidden" name="edit" id="edit" value="0" >
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="submit" id="submitForm" class="btn btn-secondary btn-info">Simpan</button>
				</fieldset>
			</form>
	  </div>
  </div>
</div>
</div>
