
<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo !empty($data) ? $judul : "Data tidak ditemukan"?></span></h3>
        <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>
<?php if(!empty($data)) {?>
<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
			<div class="table-responsive-md">
   <table class="table" border="0" cellpadding="4" style="border: none;padding-top: 7px;padding-bottom: 7px;color: #222;">
	 <?php foreach($data as $f) : ?>
	<tr>
		<td size="90"style="padding: 10px 15px;padding-top: 10px;padding-bottom: 10px;background: #fff;text-align:right"><?php echo $f?></td>
		
		<td>: <?php 
		if($f=='foto'){
			if($kolom->foto == ''){
				echo '<img src="'.base_url('public/bank/img/no-image.png').'" style="margin-left: auto; margin-right: auto; max-width: 30%;height: auto;"/>';
			}else{
			$file = base_url().'/'.$kolom->foto;
			echo '<a href="#" onclick="openNewFile('."'".$file."'".')"><img src="'.$file.'" style="margin-left: auto; margin-right: auto; max-width: 30%;height: auto;"/></a>';
			}
		}else{
		echo $kolom->$f;
		}
		
		?></td>
	</tr>
	<?php endforeach ?>
	<tr height="40">
		<td></td>
		<td><button class="btn btn-danger btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button> |</td>
	</tr>
  </table>
</div>
        </div>
	</div>
</div>

<?php }?>
