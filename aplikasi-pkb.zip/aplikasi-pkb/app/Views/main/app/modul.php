
<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul?></span></h3>
       <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
			<div id="reload">
			<button class="btn btn-primary btn-xs" data-toggle="modal" data-target="#modulLayanan"><span class="lnr lnr-sync"> Tambah</span></button>
		<table class="table table-striped" data-toggle="table" data-show-refresh="true" data-show-toggle="false" data-show-columns="true" data-search="true"  data-pagination="true" data-sort-name="name" data-sort-order="desc">
			<thead>
				<tr>
					<th>#</th>
					<th>Judul</th>
					<th>Deskripsi</th>
					<th>Status</th>
					<th>.:.</th>
				</tr>
			</thead>
			<tbody >
            <?php $no=1; foreach($isi as $row) : ?>
                <tr>
                    <td data-field="no"><?php echo $no++?></td>
                    <td><a href="<?php echo base_url('apps/modul/'.encrypt('rincian').'/'. encrypt($row->id_menu_app));?>" ><?php echo $row->judul;?></a></td>
                    <td><?php echo $row->deskripsi;?></td>
                    <td><?php echo $row->status ? "aktif" : "non aktif";?></td>
					
					<td>
                    <a href="<?php echo base_url('apps/editModul/'. encrypt($row->id_menu_app));?>" class="btn btn-info btn-xs"><span class="lnr lnr-magnifier"> Edit</span></a>
                    <a href="<?php echo base_url('apps/tambahForm/1/'. $row->id_menu_app);?>" class="btn btn-primary btn-xs"><span class="lnr lnr-pencil"> Set Form</span></a>
                    <button class="btn btn-danger btn-xs" onClick="hapusModul(<?php echo $row->id_menu_app?>)"><span class="lnr lnr-trash"> Hapus</span></button>
					</td>
                    
                </tr>
                <?php endforeach;?>
			</tbody>
		</table>
		</div>
		</div>
	</div>
</div>


<div class="modal fade" id="modulLayanan">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header ">
          <h4 class="modal-title">Tambah <?php echo ucwords($judul)?></h4>
        </div>
        
        <div class="modal-body">
			<form id="formModul" method="POST" action="">
				<fieldset>
					<div class="col-md-6">
						<label>Nama modul </label>
						<div class="form-group">
						<input type="text" name="judul" id="judul" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Deskripsi </label>
						<div class="form-group">
						<textarea name="deskripsi" id="deskripsi" class="form-control"></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label>icon</label>
						<div class="form-group">
						<input type="text" name="icon" id="icon" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Tabel (db)</label>
						<div class="form-group">
						<input type="text" name="tabel" id="tabel" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Primary key (pk)</label>
						<div class="form-group">
						<input type="text" name="pk_tabel" id="pk_tabel" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>Keyword</label>
						<div class="form-group">
						<input type="text" name="keyword" id="keyword" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Nama view</label>
						<div class="form-group">
						<input type="text" name="view" id="view" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>Nama folder</label>
						<div class="form-group">
						<input type="text" name="folder" id="folder" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>target_url</label>
						<div class="form-group">
						<input type="text" name="target_url" id="target_url" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>target_url</label>
						<div class="form-group">
						<input type="text" name="back_link" id="back_link" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>query_satu</label>
						<div class="form-group">
						<input type="text" name="query_satu" id="query_satu" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>query_dua</label>
						<div class="form-group">
						<input type="text" name="query_dua" id="query_dua" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Special query</label>
						<div class="form-group">
						<textarea name="special_query" id="special_query" class="form-control"></textarea>
						</div>
					</div>
				 	<div class="col-md-6">
						<label>Other Query</label>
						<div class="form-group">
						<textarea name="other_query" id="other_query" class="form-control"></textarea>
						</div>
					</div>
				 					
					<div class="col-md-6">
						<label>Apakah hanya untuk admin?</label>
						<div class="form-group">
						<select class="form-control" name="admin_only" id="admin_only" required>
							<option value="0">Tidak</option>
							<option value="1">Ya</option>
						</select>
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Hak akses</label>
						<div class="form-group">
						<select class="form-control" name="tipe" id="tipe" required>
							<option value="1">App only</option>
							<option value="2">Umum</option>
							<option value="3">Operator</option>
						</select>
						</div>
					</div>
					<div class="col-md-6">
					<label> Aktif </label>
					<div class="form-group">
						<select class="form-control" name="status" id="status" required>
							<option value="1">aktif</option>
							<option value="0">non aktif</option>
						</select>
					</div>
					</div>
				</fieldset>	
				<br><br>
				<fieldset>
					<input type="hidden" name="kondisi" id="kondisi" />
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="button" onClick="addModul()" class="btn btn-secondary btn-info">Simpan</button>
				</fieldset>
			</form>
        </div>
      </div>
    </div>
  </div>
  

