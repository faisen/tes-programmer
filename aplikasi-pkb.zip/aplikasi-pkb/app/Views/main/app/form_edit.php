<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul;?></span></h3>
        <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
		<form id="FormEdit" method="POST" action="<?php echo base_url($link)?>">
				<fieldset>
					<?php foreach($form as $row) : ?>
					<?php if($row->tipe == 'select') {?>
					<div class="col-md-6">
						<label><?php echo $row->label?></label>
						<div class="form-group">
						<select class="form-control <?php echo $row->kelas?>" name="<?php echo $row->nama?>" id="<?php echo $row->id?>" <?php echo $row->fungsi?> required>
							<option value="<?php echo $isi[$row->nama]?>"><?php echo $isi[$row->nama]?></option>
							<?php echo $row->konten?>
						</select>
						</div>
					</div>
					<?php }elseif($row->tipe == 'textarea'){
				echo '<div class="col-md-6">
						<label>'.$row->label.'</label>
						<div class="form-group">
						<textarea class="form-control '.$row->kelas.'" name="'.$row->nama.'" id="'.$row->id.'">'. $isi[$row->nama].'</textarea>
						<p style="color:red">'.$row->pesan.'</p>
						</div>
					</div>';
			}elseif($row->tipe == 'file'){ ?>
				<div class="col-md-6">
						<label><?php echo $row->label?></label>
						<div class="form-group">
						 <div class="tampilGanti" style="display: none;">
						 <p>Unggah file baru</p>
						 <label class="btn btn-default btn-sm center-block btn-file">
						  <i class="fa fa-upload fa-2x" aria-hidden="true"></i>
						 
						  <input type="file" id="<?php echo $row->nama?>" class="form-control fileInput <?php echo $row->kelas?>" name="<?php echo $row->nama?>" onchange="unggahFilePendukung()" accept=".pdf, .jpg, .png, .jpeg" style="display: none;"></label><br>
						  <a href="#" onclick="lihatFileAsli()">Lihat file asli</a>
						  </div>
						  <div class="tampilFileAsli" style="display: inline;">
							  <div class="tombol" style="border: 2px dotted blue; height:auto; width:auto; padding:15px;">
							  <button class="btn btn-danger btn-xs" type="button" onClick="gantiFileLoad()"><span class="lnr lnr-trash"></span></button> | <button type="button" class="btn btn-success btn-xs"  onclick="openNewFile('<?php echo base_url().'/'.$isi[$row->nama]?>')"><span class="lnr lnr-enter"></span></button>
					
							 </div>
						  </div>
						  <div class="tampilFilePendukung" style="display: none;">
							  <div class="tombol" style="border: 2px dotted blue; height:auto; width:auto; padding:15px;">
							 	<input type="hidden" name="<?php echo $row->nama?>" id="nama_file_baru" value="<?php echo $isi[$row->nama]?>" />
							 </div>
						  </div>
						<p style="color:red"> <?php echo $row->pesan ?></p>
						</div>
					</div>;
			<?php }elseif($row->tipe == 'dropdown'){
					$r = explode(",", $row->dropdown);
					$alias = '';
					if(sizeof($r) > 3){
						$alias = $r[3];
					}
					echo'<div class="col-md-6">
							<label>'.$row->label.'</label>
							<div class="form-group">
							'.dropdown($row->nama,$r[0],$r[1],$r[2],$alias,$row->nama,"form-control multiSelect", "",$isi[$row->nama]).'<p style="color:red">'.$row->pesan.'</p>
							</div>
						</div>';
				}elseif($row->under_proces){
				
				echo '<input type="hidden" name="'.$row->nama.'" value="'.$isi[$row->nama].'">';
				}else{?>
					<div class="col-md-6">
						<label><?php echo $row->label?></label>
						<div class="form-group">
						<input type="<?php echo $row->tipe?>" class="form-control <?php echo $row->kelas?>" name="<?php echo $row->nama?>" id="<?php echo $row->id?>" value="<?php echo $isi[$row->nama]?>" <?php echo $row->fungsi?> required>
						</div>
					</div>
					<?php }endforeach;?>
					<input type="hidden" name="id_menu_app" id="id_menu_app" value="<?php echo $id_menu_app?>" />
				</fieldset>	
				<br><br>
				<fieldset>
				  <button type="button" class="btn btn-secondary btn-danger" onClick="mundur()">Tutup</button>
				  <button type="submit" id="submitFormEdit" class="btn btn-secondary btn-info">Simpan</button>
				</fieldset>
			</form>
		</div>
	</div>
</div>
