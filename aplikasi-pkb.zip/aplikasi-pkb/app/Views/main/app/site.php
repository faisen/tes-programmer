
<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul?></span></h3>
		<button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
			<div id="reload">
			<button class="btn btn-info btn-xs" data-toggle="modal" data-target="#modalUbahPengaturan"><span class="lnr lnr-plus-circle"> Ubah Pengaturan</span></button>
		<table class="table table-striped" data-toggle="table" data-show-refresh="false" data-show-toggle="false" data-show-columns="false" data-search="true"  data-pagination="false" data-sort-name="name" data-sort-order="desc">
			<thead>
				<tr>
					<th>judul</th>
					<th>nama_site</th>
					<th>link</th>
					<th>logo</th>
					<th>favicon</th>
					<th>brand</th>
					<th>footer</th>
					<th>warna_base</th>
					<th>gambar_body</th>
					<th>warna_tombol</th>
				</tr>
			</thead>
			<tbody>
			<?php if(!empty($site)){?>
				<tr>
					<td><?php echo $site->judul?></td>
					<td><?php echo $site->nama_site?></td>
					<td><?php echo $site->link?></td>
					<td><img width="40px" src="<?php echo base_url($site->logo)?>" />
					<button onClick="gantiImage(<?php echo $site->id_setting?>, 1)" >Ganti</button></td>
					<td><img width="40px" src="<?php echo base_url($site->favicon)?>" />
					<button onClick="gantiImage(<?php echo $site->id_setting?>, 2)" >Ganti</button></td>
					<td><?php echo $site->brand?></td>
					<td><?php echo $site->footer?></td>
					<td><?php echo $site->warna_base?></td>
					<td><img width="40px" src="<?php echo base_url($site->gambar_body)?>" /><button onClick="gantiImage(<?php echo $site->id_setting?>, 3)" >Ganti</button></td>
					<td><?php echo $site->warna_tombol?></td>
				</tr>
			<?php }?>
			</tbody>
		</table>
		</nav>
		</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modalUbahPengaturan">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header ">
          <h4 class="modal-title">Ubah <?php echo ucwords($judul)?></h4>
        </div>
        
        <div class="modal-body">
		<?php if(!empty($site)){?>
			<form method="POST" action="<?php echo base_url('setting/editSite')?>">
				<fieldset>
					<div class="col-md-6">
						<label>judul</label>
						<div class="form-group">
						<input type="text" name="judul" id="judul" class="form-control" value="<?php echo $site->judul?>" />
						</div>
					</div>
					<div class="col-md-6">
						<label>nama_site </label>
						<div class="form-group">
						<input type="text" name="nama_site" id="nama_site" class="form-control" value="<?php echo $site->nama_site?>" />
						</div>
					</div>
					<div class="col-md-6">
						<label>link </label>
						<div class="form-group">
						<input type="text" name="link" id="link" class="form-control" value="<?php echo $site->link?>" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>brand</label>
						<div class="form-group">
						<input type="text" name="brand" id="brand" class="form-control" value="<?php echo $site->brand?>" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>footer</label>
						<div class="form-group">
						<input type="text" name="footer" id="footer" class="form-control" value="<?php echo $site->footer?>" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>warna_base</label>
						<div class="form-group">
						<input type="text" name="warna_base" id="warna_base" class="form-control" value="<?php echo $site->warna_base?>" />
						<p>bilangan hexa. #fffaaa</p>
						</div>
					</div>
					<div class="col-md-6">
						<label>warna_tombol</label>
						<div class="form-group">
						<input type="text" name="warna_tombol" id="warna_tombol" class="form-control" value="<?php echo $site->warna_tombol?>" />
						<p>bilangan hexa. #fffaaa</p>
						</div>
					</div>
				</fieldset>	
				<br><br>
				<fieldset>
					<input type="hidden" name="id_setting" id="id_setting" value="<?php echo $site->id_setting?>" />
					
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="submit" id="submitLaporanAkta" class="btn btn-secondary btn-info">Ubah</button>
				</fieldset>
			</form>
			
		<?php }else{?>
			<form method="POST" action="<?php echo base_url('setting/editSite')?>">
				<fieldset>
					<div class="col-md-6">
						<label>judul</label>
						<div class="form-group">
						<input type="text" name="judul" id="judul" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>nama_site </label>
						<div class="form-group">
						<input type="text" name="nama_site" id="nama_site" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>link </label>
						<div class="form-group">
						<input type="text" name="link" id="link" class="form-control"/>
						</div>
					</div>
					
					<div class="col-md-6">
						<label>brand</label>
						<div class="form-group">
						<input type="text" name="brand" id="brand" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>footer</label>
						<div class="form-group">
						<input type="text" name="footer" id="footer" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>warna_base</label>
						<div class="form-group">
						<input type="text" name="warna_base" id="warna_base" class="form-control" />
						<p>bilangan hexa. #fffaaa</p>
						</div>
					</div>
					<div class="col-md-6">
						<label>warna_tombol</label>
						<div class="form-group">
						<input type="text" name="warna_tombol" id="warna_tombol" class="form-control" />
						<p>bilangan hexa. #fffaaa</p>
						</div>
					</div>
				</fieldset>	
				<br><br>
				<fieldset>
					<input type="hidden" name="id_setting" id="id_setting" />
					
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="submit" class="btn btn-secondary btn-info">Ubah</button>
				</fieldset>
			</form>
			
		<?php }?>
        </div>
      </div>
    </div>
  </div>
  
<div class="modal fade" id="modalUnggahFile">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header ">
          <h4 class="modal-title">Ubah <?php echo ucwords($judul)?></h4>
        </div>
        
        <div class="modal-body">
			<form method="POST">
				<fieldset>
					<div class="col-md-6">
						<label>Pilih File</label>
						<div class="form-group">
						<input type="file" name="nama_file" id="nama_file" class="form-control" />
						<input type="hidden" name="tipe_input" id="tipe_input" />
						</div>
					</div>
					<div class="col-md-3">
						<label>Aksi</label>
						<div class="form-group">
						<button type="button" class="btn btn-info btn-xs" onClick="unggahFile(<?php echo $site->id_setting?>)"><span class="lnr lnr-arrow-right"> Unggah</span></button>
						</div>
					</div>
				</fieldset>	
				
			</form>
        </div>
      </div>
    </div>
  </div>