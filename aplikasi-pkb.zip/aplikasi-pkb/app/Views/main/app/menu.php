<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> <?php echo $judul;?></span></h3>
        <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
		<button class="btn btn-info btn-xs" onClick="tambahData(13,0)"><span class="lnr lnr-plus-circle"> Tambah menu</span></button>
		<table class="table table-striped" data-toggle="table" data-show-refresh="true" data-show-toggle="false" data-show-columns="true" data-search="true"  data-pagination="true" data-sort-name="name" data-sort-order="desc">
			<thead>
				<tr>
					<th>No</th>
					<th>Judul</th>
					<th>Ikon</th>
					<th>aktif</th>
					<th>.:.</th>
				</tr>
			</thead>
			<tbody >
			<?php
			$no=1;
			foreach ($menu as $r)
			{?>
				<tr>
				<td> <?=$no++?></td>
				<td> <?=$r->judul ?></td>
				<td> <?=$r->ikon ?></td>
				<td> <?=$r->aktif ?></td>
				<td>
					<a class="btn btn-warning btn-xs" href="<?php echo base_url('menu/edit/menu/id_menu/'.$r->id_menu);?>"><span class="lnr lnr-pencil"> Edit</span></a>
                    <button class="btn btn-info btn-xs" onClick="AddSub(11,<?php echo $r->id_menu?>)"><span class="lnr lnr-plus-circle"> Sub menu</span></button>
                    <button class="btn btn-danger btn-xs" onClick="hapusMenu(<?php echo $r->id_menu?>)"><span class="lnr lnr-trash"> Hapus</span></button>
				</td>
				</tr>
					<?php }?>
			</tbody>
		</table>
		</div>
	</div>
</div>

<div class="modal fade" id="AddMenu">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header ">
          <h4 class="modal-title">Tambah <?php echo ucwords($judul)?> Utama</h4>
        </div>
        <div class="modal-body">
			<form id="formMenu" method="POST" action="<?php echo base_url("menu/simpan")?>">
				<fieldset>
					<div class="col-md-6">
						<label>judul </label>
						<div class="form-group">
						<input type="text" name="judul" id="judul" class="form-control" />
						</div>
					</div>

					<div class="col-md-6">
						<label>icon</label>
						<div class="form-group">
						<input type="text" name="ikon" id="ikon" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
					<label> Aktif </label>
					<div class="form-group">
						<select class="form-control" name="aktif" id="sktif" required>
							<option value="y">aktif</option>
							<option value="n">non aktif</option>
						</select>
					</div>
					</div>
				</fieldset>	
				<br><br>
				<fieldset>
					<input type="hidden" name="tipeInputMenu" id="tipeInputMenu" />
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="button" onClick="saveMenu()" class="btn btn-secondary btn-info">Simpan</button>
				</fieldset>
			</form>
        </div>
      </div>
    </div>
  </div>
  
  <div class="modal fade" id="AddSubMenu">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header ">
          <h4 class="modal-title">Tambah Sub <?php echo ucwords($judul)?></h4>
        </div>
        <div class="modal-body">
			<form id="formSubMenu" method="POST" action="<?php echo base_url("menu/simpan/sub_menu/id_sub_menu")?>">
				<fieldset>
					<div class="col-md-6">
						<label>judul </label>
						<div class="form-group">
						<input type="text" name="judul_sub_menu" id="judul_sub_menu" class="form-control" />
						</div>
					</div>

					<div class="col-md-6">
						<label>icon</label>
						<div class="form-group">
						<input type="text" name="ikon_sub" id="ikon_sub" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>url</label>
						<div class="form-group">
						<input type="text" name="url" id="url" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
					<label> Aktif </label>
					<div class="form-group">
						<select class="form-control" name="aktif" id="statusSubMenu" required>
							<option value="y">aktif</option>
							<option value="n">non aktif</option>
						</select>
					</div>
					</div>
				</fieldset>	
				<br><br>
				<fieldset>
					<input type="hidden" name="id_menu" id="id_menu" />
					<input type="hidden" name="tipeInputSubMenu" id="tipeInputSubMenu" />
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="button" onClick="saveSubMenu()" class="btn btn-secondary btn-info">Simpan</button>
				</fieldset>
			</form>
        </div>
      </div>
    </div>
  </div>
  
  <div class="modal fade" id="ListSubMenu">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header ">
          <h4 class="modal-title judulSubMenu">Daftar Sub Menu</h4>
        </div>
        <div class="modal-body">
		<button class="btn btn-info btn-xs" onClick="AddSub(13,0)"><span class="lnr lnr-plus-circle"> Tambah sub menu</span></button>
		<hr>
			<table class="table table-striped" data-toggle="table" data-show-refresh="false" data-show-toggle="false" data-show-columns="false" data-search="false"  data-pagination="false" data-sort-name="name" data-sort-order="desc">
			<thead>
				<tr>
					<th>No</th>
					<th>menu induk</th>
					<th>Judul</th>
					<th>Ikon</th>
					<th>url</th>
					<th>aktif</th>
					<th>.:.</th>
				</tr>
			</thead>
			<tbody id="tampilSubMenu">
			
			</tbody>
		</table>
        </div>
      </div>
    </div>
  </div>