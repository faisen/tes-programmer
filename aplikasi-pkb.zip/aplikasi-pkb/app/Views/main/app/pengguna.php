<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
        <h3><span class="lnr lnr-home"> Data Pengguna Aplikasi</span></h3>
        <button class="btn btn-info btn-xs" onClick="mundur()"><span class="lnr lnr-arrow-left"> Kembali</span></button>
        <button class="btn btn-info btn-xs" onClick="reload()"><span class="lnr lnr-sync"> Reload</span></button>
		<div class="loading"></div>
        </div>
	</div>
</div>

<div class="col-lg">
	<div class="panel">
		<div class="panel-body">
		<button class="btn btn-info btn-xs"  data-toggle="modal" data-target="#showModalPengguna"><span class="lnr lnr-plus-circle"> Tambah data</span></button>
		<table class="table table-striped" data-toggle="table" data-show-refresh="true" data-show-toggle="false" data-show-columns="true" data-search="true"  data-pagination="true" data-sort-name="name" data-sort-order="desc">
			<thead>
				<tr>
					<th>No</th>
					<th>Nama pengguna</th>
					<th>Level</th>
					<th>Staus</th>
					<th>.:.</th>
				</tr>
			</thead>
			<tbody >
			<?php
			$no=0;
			foreach ($isi as $r)
			{
				$status = "Akif";
				if($r->status == 0){
					$status = "Non aktif";
				}
				
				$no++;
				echo '<tr>';
				echo '<td> ' . $no. '</td>';
				echo '<td> ' . $r->nama_pengguna. '</td>';
				echo '<td> ' . level($r->level) . '</td>';
				echo '<td> ' . $status . '</td>';
				echo '<td><button class="btn btn-info btn-xs" onclick="update('.$r->id_auth.')" ><span class="lnr lnr-pencil"></span></button> | <button class="btn btn-danger btn-xs" onclick="hapus('.$r->id_auth.')" ><span class="lnr lnr-trash"></span></button></td>';
				echo '</tr>';
			}
			?>
			</tbody>
		</table>
		</div>
	</div>
</div>


<div class="modal fade" id="showModalPengguna">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header ">
          <h4 class="modal-title">Tambah data</h4>
        </div>
        <div class="modal-body">
			<form id="formPengguna" method="POST" action="">
				<fieldset>
					<div class="col-md-6">
						<label>Nama Pengguna </label>
						<div class="form-group">
						<input type="text" name="nama_pengguna" id="nama_pengguna" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Kata Sandi </label>
						<div class="form-group">
						<input type="text" name="kata_sandi" id="kata_sandi" class="form-control" />
						</div>
					</div>
					<div class="col-md-6">
						<label>Level</label>
						<div class="form-group">
						<select class="form-control" name="level" id="level" required>
							<option value="1">Admin</option>
							<option value="2">Operator</option>
						</select>
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Status</label>
						<div class="form-group">
						<select class="form-control" name="status" id="status" required>
							<option value="1">Aktif</option>
							<option value="0">Non Aktif</option>
						</select>
						</div>
					</div>
				</fieldset>	
				<br><br>
				<fieldset>
				<input type="hidden" name="tipe_aksi" id="tipe_aksi" >
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="button" id="btnsave" class="btn btn-secondary btn-info" onclick="simpan()">Simpan</button>
				</fieldset>
			</form>
	  </div>
  </div>
</div>
</div>

<div class="modal fade" id="showModalUpdatePengguna">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header ">
          <h4 class="modal-title">Ubah data</h4>
        </div>
        <div class="modal-body">
			<form id="formUpdatePengguna" method="POST" action="">
				<fieldset>
					<div class="col-md-6">
						<label>Nama Pengguna </label>
						<div class="form-group">
						<input type="text" name="nama_pengguna" id="u_nama_pengguna" class="form-control" />
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Kata Sandi </label>
						<div class="form-group">
						<input type="text" name="kata_sandi" id="u_kata_sandi" class="form-control" />
						<p style="color:red">Masukan kata sandi baru jika ingin merubah kata sandi</p>
						</div>
					</div>
					<div class="col-md-6">
						<label>Level</label>
						<div class="form-group">
						<select class="form-control" name="level" id="u_level" required>
							<option value="1">Admin</option>
							<option value="2">Operator</option>
						</select>
						</div>
					</div>
					
					<div class="col-md-6">
						<label>Status</label>
						<div class="form-group">
						<select class="form-control" name="status" id="u_status" required>
							<option value="1">Aktif</option>
							<option value="0">Non Aktif</option>
						</select>
						</div>
					</div>
				</fieldset>	
				<br><br>
				<fieldset>
				<input type="hidden" name="id_auth" id="id_auth" >
				<input type="hidden" name="kata_sandi_lama" id="kata_sandi_lama" >
				  <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
				  <button type="button" id="btnsave" class="btn btn-secondary btn-info" onclick="simpanUpdate()">Simpan</button>
				</fieldset>
			</form>
	  </div>
  </div>
</div>
</div>