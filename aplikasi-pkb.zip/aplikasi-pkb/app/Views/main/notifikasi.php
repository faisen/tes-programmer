<div class="panel-group">
<div class="panel panel-info">
	<div class="panel panel-headline">
		<div class="panel-heading">
			<h3 class="panel-title">infomasi!!</h3>
			<p class="panel-subtitle"><?php echo waktu();?></p>
		</div>
		<div class="panel-body">
			<div class="row">
				<div class="col-lg">
					<div class="metric">
						<h3 class="panel-title" style="color:red" align="center">Mohon Maaf</h3>
						<h4 style="color:red" align="center">Anda Tidak Memiliki Hak Akses Ke Halaman ini</h4>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>