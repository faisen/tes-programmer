<style>
	.modal-dialog{
		padding-top: 100px;
		border-radius: 0;
		max-width:70%;
	}

	.modal-title{
		color: #4cd2ff;
	}
</style>

<!-- The Modal -->
  <div class="modal fade" id="modalPemohon">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header " style="<?php echo $css?>">
          <h4 class="modal-title"><?php echo ucwords($judulModal)?></h4>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
			//load konten pemohon
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Nama</th>
						<th>NIK</th>
						<th>ALamat</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php tampil($pemohon['pmhnNama']) ?></td>
						<td><?php tampil($pemohon['pmhnNIK']) ?></td>
						<td><?php tampil($pemohon['pmhnAlamat']) ?></td>
					</tr>
				</tbody>
			</table>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
          <button type="button" class="btn btn-secondary btn-info" data-dismiss="modal">Action</button>
        </div>
        
      </div>
    </div>
  </div>
  
  <!-- modal izin-->
  <div class="modal fade" id="modalIzin">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header " style="<?php echo $css?>">
          <h4 class="modal-title"><?php echo ucwords($judulModal)?></h4>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
			//load konten izin
			<table class="table table-striped">
				<thead>
					<tr>
						<th>ID</th>
						<th>Tanggal</th>
						<th>Lokasi</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php tampil($izin['ikesId']) ?></td>
						<td><?php tampil($izin['tglPermohonan']) ?></td>
						<td><?php tampil($izin['ikesAlamat']) ?></td>
					</tr>
				</tbody>
			</table>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-danger" data-dismiss="modal">Tutup</button>
          <button type="button" class="btn btn-secondary btn-info" data-dismiss="modal">Action</button>
        </div>
        
      </div>
    </div>
  </div>
  
  