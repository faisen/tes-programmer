<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Layanan Informasi Pendapatan</title>
<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/vendor/linearicons/style.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="<?php echo base_url('public/bank/dialog/dialog.css')?>">
	<link rel="stylesheet" href="<?php echo base_url('public/bank/dialog/sweetalert2.min.css')?>">
	<link rel="stylesheet" href="<?php echo base_url('public/bank/dialog/sweetalert2.css')?>">
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/css/style.css">
	<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/css/style_modal.css">
	
	<style type="text/css">
	.loader {
	  border: 16px solid #f3f3f3; /* Light grey */
	  border-top: 16px solid #3498db; /* Blue */
	  border-radius: 50%;
	  width: 90px;
	  height: 90px;
	  animation: spin 2s linear infinite;
	}

	@keyframes spin {
	  0% { transform: rotate(0deg); }
	  100% { transform: rotate(360deg); }
	}
	body{
		width:100%;
		height:100%;
		margin:0;
		padding:0;
	}
	.bodi{
		 background-image: url('');
		 background-size: cover;
		 background-attachment: fixed;
		 background-repeat: no-repeat; 
	}
	
	div.popup{
		position:fixed;
		top:0;
		bottom:0;
		left:0;
		right:0;
		width:auto;
		height:100%;
		background: rgba(0,0,0,.8);
		
	}
	
	div#box{
		margin: 20px auto;
    	padding: 20px;
		width:80%;
		height:auto;
		-webkit-box-shadow:0 0 15px #000;
		-moz-box-shadow:0 0 15px #000;
		box-shadow:0 0 15px #000;
	}
	
	fieldset {
	border: 1px solid #DEB887;
	display: inline-block;
	font-size: 14px;
	padding: 1em 2em;
	width:100%;
	}
	</style>
</head>
<body class="bodi">
	<div class="main">
	<br><br>
	<section class="signup">
            <!-- <img src="images/signup-bg.jpg" alt=""> -->
            <div class="container">
                <div class="signup-content">
				
                    <form method="POST" id="signup-form" class="form-auth" method="POST" action="" >
                        <center><img width="65px" src="<?php echo base_url('public/site/logo_prov.png')?>" /> </center>
						<h2 class="form-title">Layanan Informasi Pendapatan</h2>
                        <div class="form-group">
						<label>Username / ID</label>
                            <input type="text" class="form-control" name="nama_pengguna" id="nama_pengguna" placeholder="ID / Username" />
                        </div>
                        <div class="form-group">
						  <label>Password</label>
                            <input type="password" class="form-control" name="kata_sandi" id="kata_sandi" placeholder="Password">
                            <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
                        </div>
                        <div class="form-group">
                            <a href="<?= base_url('pajak/home')?>" class="btn btn-primary btn-md">MASUK</a>
                        </div>
                    </form>
                </div>
            </div>
        </section>
	
		
	</div>
    
	<script src="<?php echo base_url()?>/public/bank/scripts/jquery/jquery-3.5.1.min.js"></script>
	<script src="<?php echo base_url()?>/public/bank/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url('public/bank/scripts/dialog/sweetalert.min.js')?>"></script>
	<script src="<?php echo base_url('public/bank/scripts/dialog/dialog-active.js')?>"></script>
	<script type="text/javascript">
	$(document).ready(function(){
		//getPengumuman();
		$('a.close').click(function(eve){
			
			eve.preventDefault();
			$(this).parents('div.popup').fadeOut('slow');
		});
	});
		const form = document.querySelector("#signup-form"),
		continueBtn = form.querySelector("#submit"),
		errorText = form.querySelector(".messages-auth");
		
		
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		form.onsubmit = (e)=>{
			e.preventDefault();
		}
		
		continueBtn.onclick = ()=>{
			var dataPost = $("#signup-form").serialize();;
			if($("#nama_pengguna").val() == '' && $("#kata_sandi").val() == '' ){
				swal({   
						title: "Gagal!",   
						text: " nama_pengguna dan kata_sandi tidak boleh kosong!",   
						timer: 2000
					});
			}else{
				
				var request = $.ajax({
					url: baseUrl + "/Apps/cekLogin",
					method: "POST",
					dataType: "JSON",
					data:dataPost
				});
				
				request.done(function( data ) {
					if(data.status){
						swal("Berhasil!", "pesan : "+data.pesan, "success");
						setTimeout(function(){
							location.replace("apps");
						}, 1000);
					}else{
				
						swal("Gagal!", "pesan : "+data.pesan, "error");
						setTimeout(function(){
							location.reload();
						}, 2000);
					}
				});
				
				request.fail(function( jqXHR, textStatus ) {
					swal("Error", "Kesalahan koneksi : "+textStatus, "error"); 
				});

			}
		}
	function getPengumuman(){
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		var request = $.ajax({
					url: baseUrl + "/modul/getPengumuman/1",
					method: "GET",
					dataType: "JSON"
				});
				
				request.done(function( data ) {
					if(data.status){
						var baris='';
						var no=0;
						var path ='';
						for(var i=0; i<data.pengumuman.length; i++){
							no = ++no;
							path = '<?php echo base_url()?>/'+data.pengumuman[i].nama_file;
							baris +='<fieldset><p>Judul : '+data.pengumuman[i].judul+'</p>'
							+'<p>Tanggal: '+data.pengumuman[i].tanggal_input+'</p><p>isi : </p>'+'<hr>'+'<h5>" '+data.pengumuman[i].isi+' - <a onclick="openNewFile('+"'"+path+"'"+')"  class="btn btn-info btn-xs"> Lihat Lampiran</a></h5></fieldset><br><br>';
									
						}
						$('#isiPengumuman').html(baris);
					}
				});
				
				request.fail(function( jqXHR, textStatus ) {
					swal("Error", "Kesalahan koneksi : "+textStatus, "error"); 
				});
	}
	
	function openNewFile(url) {
		popupWindow = window.open(url,'popUpWindow','height=600,width=1000,left=450px,top=200px,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes');
		popUpWindow.onload = function(){
			this.document.title = 'judul';
		}
	}
	</script>
</body>
</html>

