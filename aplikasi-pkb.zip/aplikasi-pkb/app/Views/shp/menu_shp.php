<link rel="stylesheet" href="<?php echo base_url()?>/public/bank/css/shp/style_shp.css">


<div class="row">
	<div class="col-lg-12">
		<div class="table-responsive-md">
			<div class="_2hR6ab">
			<?php for($i=0; $i<2; $i++){ ?>
			<a href="/m/shopee-pilih-lokal">
			<div style="width: 100px;" class="_3tuiT8">
				<div class="_9D1-HY MjGK8Q">
					<div class="_25_r8I _1RBcpk">
					<div class="_3fOtV7 _2GchKS" style="background-image: url(&quot;https://cf.shopee.co.id/file/ae2620ecee6471a9591ba310feb831be_xhdpi&quot;); background-size: contain; background-repeat: no-repeat;">
					</div>
					</div>
				</div>
				<div class="_2GYM92 MWc1_R">Shopee Pilih Lokal</div>
			</div>
			</a>

			<a href="/m/elektronik-100-ori">
				<div style="width: 100px;" class="_3tuiT8">
					<div class="_9D1-HY MjGK8Q">
						<div class="_25_r8I _1RBcpk">
							<div class="_3fOtV7 _2GchKS" style="background-image: url(&quot;https://cf.shopee.co.id/file/fe02a504f64b146f90af16947ae65d08_xhdpi&quot;); background-size: contain; background-repeat: no-repeat;">
							</div>
						</div>
					</div>
				<div class="_2GYM92 MWc1_R">Elektronik 100% ORI</div>
				</div>
			</a>

			<a href="/produk-digital">
				<div style="width: 100px;" class="_3tuiT8">
					<div class="_9D1-HY MjGK8Q">
						<div class="_25_r8I _1RBcpk">
							<div class="_3fOtV7 _2GchKS" style="background-image: url(&quot;https://cf.shopee.co.id/file/5164f9b1e9319def7e609101eb3c9349_xhdpi&quot;); background-size: contain; background-repeat: no-repeat;">
							</div>
						</div>
					</div>
					<div class="_2GYM92 MWc1_R">Pulsa, Tagihan &amp; Hiburan</div>
				</div>
			</a>
			<?php }?>
			</div>
		</div>
		<div class="table-responsive-md">
			<div class="_2hR6ab">
			<?php for($i=0; $i<2; $i++){ ?>
			<a href="/m/shopee-pilih-lokal">
			<div style="width: 100px;" class="_3tuiT8">
				<div class="_9D1-HY MjGK8Q">
					<div class="_25_r8I _1RBcpk">
					<div class="_3fOtV7 _2GchKS" style="background-image: url(&quot;https://cf.shopee.co.id/file/ae2620ecee6471a9591ba310feb831be_xhdpi&quot;); background-size: contain; background-repeat: no-repeat;">
					</div>
					</div>
				</div>
				<div class="_2GYM92 MWc1_R">Shopee Pilih Lokal</div>
			</div>
			</a>

			<a href="/m/elektronik-100-ori">
				<div style="width: 100px;" class="_3tuiT8">
					<div class="_9D1-HY MjGK8Q">
						<div class="_25_r8I _1RBcpk">
							<div class="_3fOtV7 _2GchKS" style="background-image: url(&quot;https://cf.shopee.co.id/file/fe02a504f64b146f90af16947ae65d08_xhdpi&quot;); background-size: contain; background-repeat: no-repeat;">
							</div>
						</div>
					</div>
				<div class="_2GYM92 MWc1_R">Elektronik 100% ORI</div>
				</div>
			</a>

			<a href="/produk-digital">
				<div style="width: 100px;" class="_3tuiT8">
					<div class="_9D1-HY MjGK8Q">
						<div class="_25_r8I _1RBcpk">
							<div class="_3fOtV7 _2GchKS" style="background-image: url(&quot;https://cf.shopee.co.id/file/5164f9b1e9319def7e609101eb3c9349_xhdpi&quot;); background-size: contain; background-repeat: no-repeat;">
							</div>
						</div>
					</div>
					<div class="_2GYM92 MWc1_R">Pulsa, Tagihan &amp; Hiburan</div>
				</div>
			</a>
			<?php }?>
			</div>
		</div>
	</div>	
</div>