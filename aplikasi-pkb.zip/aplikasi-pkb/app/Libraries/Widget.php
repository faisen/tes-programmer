<?php 
namespace App\Libraries;
use App\Models\Dapur;
use App\Models\AppModel;

class Widget
{
	public $model='';
    public function recentPost(array $params)
    {
        return view('widget/recent_post', $params);
    }
	
	public function web()
    {
		$mdl = new Dapur(['table' =>'setting', 'pk' => 'id_setting']);
		$site = $mdl->bagian()->getRow();
		return $site;
    }
	
	public function getUrlNow()
    {
		$uri = current_url(true);
		
		if($uri->getSegment(1)==''){
			$url = $uri->getSegment(0);
		}else{
			$url = (string)$uri->getSegment(1);
		}
		return $url;
    }
	
	public function getMainMenu()
	{
		 $view = '';
    	$this->model = new AppModel();
		$menu = $this->model->getMenuPegawai()->getResult();
		foreach($menu as $row){
			$view .= '<li><a href="#subPages'.$row->judul.'" data-toggle="collapse" class="collapsed"><i class="'.$row->ikon.'"></i> <span>'.strtoupper($row->judul);
			$submenu = $this->getSubMenu($row->id_pegawai, $row->id_menu);
			$view .= '</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a><div id="subPages'.$row->judul.'" class="collapse ">';
			foreach($submenu as $r){
				$view .= '<ul class="nav"><li><a href="'.site_url($r->url).'" class=""> <i class="'.$r->ikon.'"></i>'.$r->judul_sub_menu.'</a></li></ul>';
			}
			$view .= '</div></li>';
		}

		return $view;
	}
	
	public function getSubMenu($id_pegawai, $id)
	{
		$mdl = new Dapur(['table' => 'layanan', 'pk' => 'id_layanan']);
		//$data = $this->model->getSubMenuById($id)->getResult();
		$sql = "SELECT sub_menu.* FROM akses_menu INNER JOIN sub_menu ON sub_menu.id_sub_menu=akses_menu.id_sub_menu WHERE id_pegawai=".$id_pegawai." AND akses_menu.id_menu=".$id;
		$data2 = $mdl->generateQuery($sql)->getResult(); 
		return $data2;
	}
	
	public function getInstansi()
	{
		$mdl = new Dapur(['table' => 'satuan_kerja', 'pk' => 'id_satuankerja']);
		$data = $mdl->semua();
		$vw ='<option value="">..pilih..</option>';
			foreach($data as $row){
				$vw .='<option value="'.$row->id_satuankerja.'">'.$row->unit_kerja.'</option>';
			}
		return $vw;
	}
	
	public function getMenuApp()
	{
		$mdl = new Dapur(['table' => 'layanan', 'pk' => 'id_layanan']);
		$data = $mdl->berdasarkan('', ['jenis_layanan'=>2])->getResult();
		$vw ='';
			foreach($data as $row){
				$vw .='<li><a href="'.base_url().'/modul/getDataForm/'.encrypt($row->id_layanan).'" class=""><i class="lnr lnr-user"></i> '.$row->judul.'</a></li>';
			}
		return $vw;
	}
	
	public function getProvinsi()
	{
		$mdl = new Dapur(['table' => 'provinsi', 'pk' => 'id_prov']);
		$data = $mdl->berdasarkan('', ['id_prov'=>17])->getResult();
		$vw ='<option value="">..pilih..</option>';
			foreach($data as $row){
				$vw .='<option value="'.$row->id_prov.'">'.$row->nama_prov.'</option>';
			}
		return $vw;
	}
	
	public function getSyarat()
	{
		$mdl = new Dapur(['table' => 'master_syarat', 'pk' => 'id_syarat']);
		$data = $mdl->berdasarkan('', ['status'=>1])->getResult();
		$vw ='<option value="">..pilih..</option>';
			foreach($data as $row){
				$vw .='<option value="'.$row->id_syarat.'">'.$row->judul.'</option>';
			}
		return $vw;
	}
	
	public function getJenisLayanan()
	{
		$mdl = new Dapur(['table' => 'layanan', 'pk' => 'id_layanan']);
		$data = $mdl->berdasarkan('', ['jenis_layanan'=>1, 'status'=>1])->getResult();
		$vw ='<option value="">..pilih..</option>';
			foreach($data as $row){
				$vw .='<option value="'.$row->id_layanan.'">'.$row->deskripsi.'</option>';
			}
		return $vw;
	}
	public function getNamaOpdPengguna()
	{
		$mdl = new Dapur(['table' => 'buku_jabatan', 'pk' => 'id_buku_jabatan']);
		$query ="SELECT kode_satu,unit_kerja FROM buku_jabatan inner join satuan_kerja on id_satuan_kerja=kode_satu WHERE buku_jabatan.nip = '".session('id_pengguna')."' AND buku_jabatan.status=1";
		$data = $mdl->generateQuery($query)->getRow();
		$vw ='<option value="">..pilih..</option>';
		if($data){
			// $sql ="SELECT * FROM sub_satuan_kerja WHERE id_satuan_kerja= '2F'";
			// $sub_opd = $mdl->generateQuery($sql)->getResult();
			// if(count($sub_opd) > 0){
				// foreach($sub_opd as $row){
			// $vw .= '<option value="'.$row->id_sub_satuan_kerja.'">'.$row->nama_satuan.'</option>';
					
				// }
			// }else{
			$vw = '<option value="'.$data->kode_satu.'">'.$data->unit_kerja.'</option>';
			//}
		}
		return $vw;
	}
	
	public function getNotifikasi(){
		$view = '<li><a href="'.base_url().'/modul/pengumuman" class="notification-item"><span class="dot bg-info"></span>Pengumuman</a></li>';
		return $view;
	}
	public function getFotoNotaris(string $id_notaris)
	{
		$mdl = new Dapur(['table' => 'identitas_pegawai', 'pk' => 'nip']);
		$query1 ="SELECT foto FROM identitas_pegawai WHERE nip = '".$id_notaris."'";
		$data1 = $mdl->generateQuery($query1)->getRow();
		$vw='';
		if($data1->foto != null){
			$vw = $data1->foto;
		}else{
			$vw = "no image";
		}
		return $vw;
	}
	public function getJumlahNotifikasi(){
		$view = 11;
		return $view;
	}
	public function getDataNotaris(){
		$mdl = new Dapur(['table' => 'notaris', 'pk' => 'id_notaris']);
		$data = $mdl->semua();
		$vw ='';
			foreach($data as $row){
				$vw .='<option value="'.$row->id_notaris.'">'.$row->nama.'</option>';
			}
		return "ada";
	}

	public function getNamaOpd(string $kode)
	{
		$mdl = new Dapur(['table' => 'satuan_kerja', 'pk' => 'id_satuan_kerja']);
		$data = $mdl->berdasarkan('', ['id_satuan_kerja'=>$kode])->getRow();
		if(empty($data)){
			return " ";
		}else{
			return $data->unit_kerja;
		}
	}
	
	
	public function getformApp(int $id_menu_app)
	{
		$mdl = new Dapur(['table' => 'form_app', 'pk' => 'id_form_app']);
        $data = $mdl->tertentu(['id_menu_app'=>$id_menu_app])->getResult();
		$vw = '';
		foreach($data as $row) {
			if($row->tipe == 'select') {
			$vw .='<div class="col-md-6">
						<label>'.$row->label.'</label>
						<div class="form-group">
						<select class="form-control '.$row->kelas.'" name="'.$row->nama.'" id="'.$row->id.'" '.$row->fungsi.'required>
							<option value="">pilih..</option>.'.$row->konten.'
						</select>
						<p style="color:red">'.$row->pesan.'</p>
						</div>
					</div>';
			}elseif($row->tipe == 'textarea'){
				$vw .='<div class="col-md-6">
						<label>'.$row->label.'</label>
						<div class="form-group">
						<textarea class="form-control '.$row->kelas.'" name="'.$row->nama.'" id="'.$row->id.'"></textarea>
						<p style="color:red">'.$row->pesan.'</p>
						</div>
					</div>';
			}elseif($row->tipe == 'file'){
				$vw .='<div class="col-md-6">
						<label>'.$row->label.'</label>
						<div class="form-group">
						<label class="btn btn-default btn-sm center-block btn-file">
						  <i class="fa fa-upload fa-2x" aria-hidden="true"></i>
						  <input type="file" id="'.$row->nama.'" class="form-control fileInput '.$row->kelas.'" name="'.$row->nama.'" onchange="unggahFilePendukung()" accept=".pdf, .jpg, .png, .jpeg" style="display: none;"></label>
						  <div class="tampilFilePendukung" style="display: none;">
						  <div class="tombol" style="border: 2px dotted blue; height:auto; width:auto; padding:15px;">
						 <input type="hidden" name="'.$row->nama.'" id="nama_file_baru" />
						 </div>
						  </div>
						<p style="color:red">'.$row->pesan.'</p>
						</div>
					</div>';
			}elseif($row->tipe == 'dropdown'){
				$r = explode(",", $row->dropdown);
				$alias = '';
				if(sizeof($r) > 3){
					$alias = $r[3];
				}
				$vw .='<div class="col-md-6">
						<label>'.$row->label.'</label>
						<div class="form-group">
						'.dropdown($row->nama,$r[0],$r[1],$r[2],$alias,"","form-control multiSelect").'<p style="color:red">'.$row->pesan.'</p>
						</div>
					</div>';
			}elseif($row->under_proces){
				
				$code = $this->buildFucntion($row->fungsi);
				$vw .= '<input type="hidden" name="'.$row->nama.'" value="'.$code.'">';
			}else{
			$vw .='<div class="col-md-6">
						<label>'.$row->label.'</label>
						<div class="form-group">
						<input type="'.$row->tipe.'" class="form-control '. $row->kelas.'" name="'.$row->nama.'" id="'.$row->id.'" '.$row->fungsi.' required>
						<p style="color:red">'.$row->pesan.'</p>
						</div>
					</div>';
			}
		}
		return $vw;
	}
	
	public function getFormVerifikasi(string $id_pengajuan, int $level)
	{
		$mdl = new Dapur(['table' => 'berkas_syarat', 'pk' => 'id_berkas_syarat']);
        $cekBerkas = $mdl->tertentu(['id_pengajuan'=>$id_pengajuan])->getResult();
		$sql = 'SELECT master_syarat.judul, berkas_syarat.* FROM berkas_syarat INNER JOIN master_syarat ON berkas_syarat.id_syarat=master_syarat.id_syarat WHERE berkas_syarat.id_pengajuan ="'.$id_pengajuan.'" AND berkas_syarat.status=2';
		$data = $mdl->generateQuery($sql)->getResult();
		
		$sql2 = 'SELECT * FROM berkas_lampiran WHERE berkas_lampiran.id_pengajuan ="'.$id_pengajuan.'" AND status=2';
		$data2 = $mdl->generateQuery($sql)->getResult(); 
		
		$vw = '';
		if(count($data) > 0 OR count($data2) > 0){
			$no=1;
			$catatan='';
			$syarat='';
			foreach($data as $row){
				$catatan .= $no++ .'.'.$row->catatan."-";
				$syarat .= $row->judul."";
			}
				$vw .='<h3 style="color:red"> Perhatian, Anda harus Rollback permohonan permohonan ini!</h3>';
					$vw .='<div class="row"><div class="col-md-12"><blockquote class="blockquote blockquote-warning" style="background-color:#ff4000;" > <i class=" mdi mdi-information icon-md text-warning"></i><h4 style="color:#ffffff"> *). Syarat : '.$syarat.' Catatan: '.$catatan.'</h4></blockquote></div></div>';
			return $vw;
		}elseif(empty($cekBerkas)){
			$vw .='<h3 style="color:red"> Perhatian, Anda harus Rollback permohonan permohonan ini!</h3><div class="row"><div class="col-md-12"><blockquote class="blockquote blockquote-warning" style="background-color:#ff4000;" > <i class=" mdi mdi-information icon-md text-warning"></i><h4 style="color:#ffffff"> *).Berkas syarat tidak diunggah</h4></blockquote></div></div>';
			return $vw;
		}else{
			return $vw;
		}
	}
	
	public function getInfoVerifikasi(string $id_pengajuan)
	{
		$mdl = new Dapur(['table' => 'verifikasi_berkas', 'pk' => 'id_verifikasi']);
        $data = $mdl->tertentu(['id_pengajuan'=>$id_pengajuan],'*', null, 0, '', 'status_verifikasi ASC')->getResult();
		$vw = '';
		if(count($data) > 0){
			$no=1;
			$catatan='';
			$syarat='';
			foreach($data as $row){
				$vw .='<div class="row"><div class="col-md-12"><blockquote class="blockquote blockquote-warning" style="background-color:#eeeeee;" > <i class=" mdi mdi-information icon-md text-warning"></i>';
				$vw .='<h4> *). Diverifikasi pada : '.tgl_indojam($row->tanggal_verifikasi, ":").'</h4>';
				$vw .='<h4> *). Status : <span class="label label-warning">'.statusVerifikasi($row->status_verifikasi).'</span></h4>';
				$vw .='<h4> *). Keterangan : '.$row->keterangan.'</h4>';
				$vw .='</blockquote></div></div>';
				
			}
		}
		return $vw;
	}
	
	public function getMenuTabs(string $id_detail_menuapp, string $id_data)
	{
		$appmodel = new AppModel();
		$app = $appmodel->getDetailMenuApp($id_detail_menuapp)->getRow();
        $mdl = new Dapur(['table' =>$app->tabel, 'pk' => $app->pk_tabel]);
   		// $detailApp = "SELECT $app->query_dua FROM $app->tabel WHERE $app->pk_tabel=$id_data";    
        // $query = $mdl->generateQuery($detailApp);
        $dataOut = $mdl->tertentu([$app->pk_tabel=>$id_data], $app->query_satu);    
		if(!empty($dataOut->getRow())){		
			$tabs['isi']        = $dataOut->getRowArray();      
			$tabs['isiJamak']        = $dataOut->getResult();      
			$tabs['header']      = $dataOut->getFieldNames();        
			$tabs['pk']  = $app->pk_tabel; 
			$tabs['id_menu_induk']  = $app->id_menu_induk; 
			return view('layout/'.$app->tipe_view, $tabs);
		}else{
			return '<img src="'.base_url('public/bank/img/not_found_2.png').'"style="margin-left: auto; margin-right: auto; max-width: 30%;height: auto;"/>';
		}
		// return " ada";
	}
	
	public function specialMenu(string $id_detail_menuapp, string $id_data)
	{
		$appmodel = new AppModel();
		$app = $appmodel->getDetailMenuApp($id_detail_menuapp)->getRow();
        $mdl = new Dapur(['table' =>$app->tabel, 'pk' => $app->pk_tabel]);
            
		if(empty($id_data)){
			$dataOut = $mdl->generateQuery($app->query_satu);
		}else{
			$select = "SELECT $apps->query_satu FROM $apps->tabel WHERE $app->pk_tabel=$id_data";
			$dataOut = $mdl->generateQuery($select);
		}
		if(!empty($dataOut->getResult())){		
			$tabs['header'] = $dataOut->getFieldNames();        
			$tabs['isi']    = $dataOut->getResult();      
			$tabs['pk']  	= $app->pk_tabel; 
			return view('layout/'.$app->tipe_view, $tabs);
		}else{
			return '<img src="'.base_url('public/bank/img/not_found_2.png').'"style="margin-left: auto; margin-right: auto; max-width: 30%;height: auto;"/>';
		}
		// return " ada";
	}
	
	public function getPensiun(string $nip, string $tanggal_lahir)
	{
        $mdl = new Dapur(['table' =>'buku_jabatan', 'pk' => 'nip']);
        $tgl = date('Y-m-d', strtotime('+55 year', strtotime($tanggal_lahir)));
		
		return $tgl;
	}
	
	function buildFucntion(string $params=''){
		$param = explode(",", $params);
		switch ($param[0]) 
        {
            case 'guc':
                return $this->generateUnicCode($param[1],$param[2]);
            break;
			case '02':
                return 'Februari';
            break;
			case '03':
                return 'Maret';
            break;
     
		}
	}
	
	function generateUnicCode($param1,$param2){
		
		$mdl = new Dapur(['table' =>$param1, 'pk' => $param2]);
		//10.000 2021 01 01
		return (int) $mdl->hitung() + 1 . date('Ymd');
    }
}