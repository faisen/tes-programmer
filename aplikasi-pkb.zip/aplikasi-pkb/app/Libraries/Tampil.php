<?php 
namespace App\Libraries;
use App\Models\MenuModel;

class Tampil
{
	public $model='';
    public function recentPost(array $params)
    {
        return view('widget/recent_post', $params);
    }
	
	public function getUrlNow()
    {
		$uri = current_url(true);
		
		if($uri->getSegment(2)==''){
			$url = $uri->getSegment(1);
		}else{
			$url = (string)$uri->getSegment(2).'/'.$uri->getSegment(3);
		}
		return $url;
    }
	public function getMainMenu()
	{
		$view = '';
		$this->model= new MenuModel();
		$data = $this->model->getMainMenu()->getResult();
		foreach($data as $row ){
			$view .= '<button class="btn btn-success success-icon-notika btn-lg"><i class="'.$row->ikon.'"></i> '.strtoupper($row->judul).'</button>';
		}
		return $view;
		//echo json_encode($data);
	}
	
}