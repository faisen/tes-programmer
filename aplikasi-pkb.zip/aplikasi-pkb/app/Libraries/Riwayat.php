<?php

namespace App\Libraries;

use App\Models\Dapur;
use App\Controllers\BaseController;

class Riwayat
{
	public $model = '';
	public $nip = '';
	public $nik = '';
	public $table = '';
	public $primarykey = '';


	public function __construct(array $config)
	{
		//$this->model = new Dapur();
		$this->setel($config);
	}

	public function setel(array $config)
	{

		foreach ($config as $key => $val) {
			if (isset($this->$key)) {
				$this->$key = $val;
			}
		}
		return $this;
	}

	// KELUARGA --------------------------------------------------------------------------------

	public function getKeluarga($nip = '', $id = '')
	{
		$mdl  = new Dapur(['table' => $this->table, 'pk' => $this->primarykey]);

		if (!empty($id)) {
			return $mdl->tertentu(['nip' => $nip, 'id_keluarga' => $id]);
		} else {
			return $mdl->tertentu(['nip' => $nip]);
		}
	}

	function simpanKeluarga($data, $mdl, $id = '')
	{
		if (empty($id)) {
			return $mdl->simpan($data, "simpan keluarga");
		} else {
			return $mdl->ubah($id, $data, "ubah keluarga");
		}
	}

	// PENDIDIKAN --------------------------------------------------------------------------------

	public function getPendidikan($nip = '', $id = '')
	{
		$mdl  = new Dapur(['table' => $this->table, 'pk' => $this->primarykey]);

		if (!empty($id)) {
			return $mdl->tertentu(['nip' => $nip, 'id_pendidikan' => $id]);
		} else {
			return $mdl->tertentu(['nip' => $nip]);
		}
	}

	function simpanPendidikan($data, $mdl, $id = '')
	{
		if (empty($id)) {
			return $mdl->simpan($data, "simpan pendidikan");
		} else {
			return $mdl->ubah($id, $data, "ubah pendidikan");
		}
	}

	// JABATAN --------------------------------------------------------------------------------

	public function getJabatan($nip = '', $id = '')
	{
		$mdl  = new Dapur(['table' => $this->table, 'pk' => $this->primarykey]);

		if (!empty($id)) {
			return $mdl->tertentu(['nip' => $nip, 'id_jabatan' => $id]);
		} else {
			return $mdl->tertentu(['nip' => $nip]);
		}
	}

	function simpanJabatan($data, $mdl, $id = '')
	{
		if (empty($id)) {
			return $mdl->simpan($data, "simpan jabatan");
		} else {
			return $mdl->ubah($id, $data, "ubah jabatan");
		}
	}

	// DIKLAT --------------------------------------------------------------------------------

	public function getDiklat($nip = '', $id = '')
	{
		$mdl  = new Dapur(['table' => $this->table, 'pk' => $this->primarykey]);

		if (!empty($id)) {
			return $mdl->tertentu(['nip' => $nip, 'id_diklat' => $id]);
		} else {
			return $mdl->tertentu(['nip' => $nip]);
		}
	}

	function simpanDiklat($data, $mdl, $id = '')
	{
		if (empty($id)) {
			return $mdl->simpan($data, "simpan diklat");
		} else {
			return $mdl->ubah($id, $data, "ubah diklat");
		}
	}

	// HUKUMAN --------------------------------------------------------------------------------

	public function getHukuman($nip = '', $id = '')
	{
		$mdl  = new Dapur(['table' => $this->table, 'pk' => $this->primarykey]);

		if (!empty($id)) {
			return $mdl->tertentu(['nip' => $nip, 'id_hukuman' => $id]);
		} else {
			return $mdl->tertentu(['nip' => $nip]);
		}
	}

	function simpanHukuman($data, $mdl, $id = '')
	{
		if (empty($id)) {
			return $mdl->simpan($data, "simpan hukuman");
		} else {
			return $mdl->ubah($id, $data, "ubah hukuman");
		}
	}

	// PENGHARGAAN --------------------------------------------------------------------------------

	public function getPenghargaan($nip = '', $id = '')
	{
		$mdl  = new Dapur(['table' => $this->table, 'pk' => $this->primarykey]);

		if (!empty($id)) {
			return $mdl->tertentu(['nip' => $nip, 'id_penghargaan' => $id]);
		} else {
			return $mdl->tertentu(['nip' => $nip]);
		}
	}

	function simpanPenghargaan($data, $mdl, $id = '')
	{
		if (empty($id)) {
			return $mdl->simpan($data, "simpan penghargaan");
		} else {
			return $mdl->ubah($id, $data, "ubah penghargaan");
		}
	}

	// BAHASA --------------------------------------------------------------------------------

	public function getBahasa($nip = '', $id = '')
	{
		$mdl  = new Dapur(['table' => $this->table, 'pk' => $this->primarykey]);

		if (!empty($id)) {
			return $mdl->tertentu(['nip' => $nip, 'id_bahasa' => $id]);
		} else {
			return $mdl->tertentu(['nip' => $nip]);
		}
	}

	function simpanBahasa($data, $mdl, $id = '')
	{
		if (empty($id)) {
			return $mdl->simpan($data, "simpan bahasa");
		} else {
			return $mdl->ubah($id, $data, "ubah bahasa");
		}
	}

	// KURSUS --------------------------------------------------------------------------------

	public function getKursus($nip = '', $id = '')
	{
		$mdl  = new Dapur(['table' => $this->table, 'pk' => $this->primarykey]);

		if (!empty($id)) {
			return $mdl->tertentu(['nip' => $nip, 'id_kursus' => $id]);
		} else {
			return $mdl->tertentu(['nip' => $nip]);
		}
	}

	function simpanKursus($data, $mdl, $id = '')
	{
		if (empty($id)) {
			return $mdl->simpan($data, "simpan kursus");
		} else {
			return $mdl->ubah($id, $data, "ubah kursus");
		}
	}
	
	
	// golongan dan pangkat --------------------------------------------------------------------------------

	public function getGolongan($nip = '', $id = '')
	{
		$mdl  = new Dapur(['table' => $this->table, 'pk' => $this->primarykey]);

		if (!empty($id)) {
			return $mdl->tertentu(['nip' => $nip, 'id_kursus' => $id]);
		} else {
			return $mdl->tertentu(['nip' => $nip]);
		}
	}

	function simpanGolongan($data, $mdl, $id = '')
	{
		if (empty($id)) {
			return $mdl->simpan($data, "simpan kursus");
		} else {
			return $mdl->ubah($id, $data, "ubah kursus");
		}
	}
}
