<?php namespace App\Models;

use CodeIgniter\Model;

class AppModel extends Model
{
    // protected $table         = 'menu';
    // protected $allowedFields = [
        // 'username', 'email', 'password'
    // ];
    // protected $returnType    = 'App\Entities\Pegawai';
    // protected $useTimestamps = true;
	protected $table         = '';
	protected $builder       = '';
	public function __construct($config = array())
	{
		parent::__construct();
		$this->builder = $this->db->table('menu_app');
	}
	public function simpan($data){
		return $this->db->table('menu_app')->insert($data);
	}
	
	public function ubah($id, $data){
		return $this->db->table('menu_app')->where('id_menu_app', $id)->update($data);
	}
	
	public function hapus($id){

		return $this->db->table('menu_app')->where('id_menu_app', $id)->delete();
	}
	
	public function semua($limit = null, $offset = 0, $grup='', $order='')
	{
		$sql = $this->builder();
		if(isset($grup)){
			$sql->groupBy($grup);
			}
			if(isset($order)){
				$sql->orderBy($order);
			}
		return $sql->get($limit, $offset)->getResult();
	}

	public function bagian($limit=null, $offset=0)
	{
		return $this->builder->get($limit, $offset);
	}
	public function berdasarkan($id = null, $kondisi = null)
	{
		if (isset($kondisi)) {
			return $this->builder->getWhere($kondisi);
		} else {
			return $this->builder->getWhere(['id_menu_app'=> $id]);
		}
	}

	public function tertentu($where = null, $kolom = '*', $limit = null, $offset = 0, $grup='', $order='')
	{
		$query = $this->builder->select($kolom)->where($where);
			if(isset($grup)){
			$query->groupBy($grup);
			}
			if(isset($order)){
				$query->orderBy($order);
			}
		return $query->get($limit, $offset);
	}
	public function hitung(){
		return $this->builder->countAllResults();
	}
	
	private function setTabel()
	{
		$this->builder = $this->db->table('menu_app');
		return $this;
	}
	public function getField($tabel)
	{
		return $this->db->getFieldData($tabel);
	}
	
	public function apps(int $id=0)
	{
		if($id !=0){
			return $this->db->table('menu_app')->where('id_menu_app', $id)->get();
		}else{
			return $this->db->table('menu_app')->get();
		}
	}
	
	public function step(int $id=0)
	{
		if($id !=0){
			return $this->db->table('input_step')->where('id_menu_app', $id)->get();
		}else{
			return $this->db->table('input_step')->get();
		}
	}
	public function aktiveStep(int $id=0, int $urutan=1)
	{
	
		return $this->db->table('input_step')->where(['id_menu_app'=> $id, 'urutan'=>$urutan])->get()->getRow();
	}
	
	public function getForm(int $id=0)
	{
		return $this->db->table('form_app')->where('id_menu_app', $id)->get();
	}
	
	public function saveDataForm($tabel, $pkTabel, $data=[], $pkTabelValue=null)
	{
		$cek = false;
		if(!empty($pkTabelValue)){
			$cek = $this->db->table($tabel)->where($pkTabel, $pkTabelValue)->update($data);
		}else{
			$cek = $this->db->table($tabel)->insert($data);
		}
		return $cek;
	}
	public function getDetailMenuApp(int $id=0)
	{
		if($id !=0){
			return $this->db->table('detail_menuapp')->where('id_detail_menuapp', $id)->get();
		}else{
			return $this->db->table('detail_menuapp')->get();
		}
	}
	
	/*
	| Opsi tampil data
	| bagaimana data tersebut ditampilkan
	|
	*/
	public function opsiTampil(int $id=0, int $urutan=1)
	{
		
		return $this->db->table('tampil_opsi')->where(['id_menu_app'=> $id, 'urutan'=>$urutan])->get()->getRow();
	}
	
	public function setQuery($query)
	{
		return $this->db->query($query);
	}
	
	public function getMenuPegawai($tipe = 0){
		$query = $this->db->table('akses_menu')
				->select('menu.judul,menu.ikon,akses_menu.id_menu, akses_menu.id_sub_menu,akses_menu.id_pegawai')
				->distinct()
				->join('menu', 'menu.id_menu=akses_menu.id_menu')
				->where('akses_menu.aktif', 'y')
				->where('akses_menu.id_pegawai', session('id_pengguna'))
				->groupBy('akses_menu.id_menu')
				->get();
		return $query;
	}
}