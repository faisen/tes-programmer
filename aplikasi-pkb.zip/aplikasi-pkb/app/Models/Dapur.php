<?php

namespace App\Models;

use CodeIgniter\Model;

class Dapur extends Model
{
	/**
	 * status setiap aksi yang dikerjakan
	 * @var boolean
	 */
	public $status         = false;

	/**
	
	 * pesan error setiap aksi yang dikerjakan
	 * @var string
	 */
	public $pesanError       = '';
	/*
	* table pada database
	*/
	protected $table         = '';
	protected $builder       = '';

	/**
	 * pilih kolom yang akan diizinkan pada tabel
	 * @var string
	 */
	/**
	 * mengaktifkan tanggal pada server
	 * @var boolean
	 */
	protected $useTimestamps = true;

	/**
	 * menentukan primary key pada tabel
	 * @var string
	 */
	protected $pk 	 = '';

	protected $allowedFields = [];
	/**
	 * menentukan entitas setiap tabel
	 * @var string
	 */
	protected $returnType    = 'App\Entities\Dapur';

	public function __construct($config = array())
	{
		parent::__construct();

		$this->konfigurasi($config);
		$this->setTabel();
	}

	public function konfigurasi($config)
	{
		foreach ($config as $key => $val) {
			if (isset($this->$key)) {
				$this->$key = $val;
			}
		}
		return $this;
	}

	private function setTabel()
	{
		$this->builder = $this->db->table($this->table);
		// $this->pk 	 = 'id_' . $this->table;
		return $this;
	}

	public function pesan()
	{
		if ($this->status) {
			$this->pesanError = ", Proses berhasil";
		} else {
			$this->pesanError = ", Proses dibatalkan";
		}
		return $this->pesanError;
	}
	
	public function simpan($data, $func = '')
	{
		$this->status = $this->builder->insert($data);
		return $func . $this->pesan();
	}

	public function ubah($val, $data, $func = '')
	{
		$this->status = $this->builder->where($this->pk, $val)->update($data);
		return $func . $this->pesan();
	}

	public function hapus($val, $func = '')
	{

		$this->status = $this->builder->where($this->pk, $val)->delete();
		return $func . $this->pesan();
	}

	public function semua($limit = null, $offset = 0, $grup='', $order='')
	{
		$sql = $this->builder();
		if(isset($grup)){
			$sql->groupBy($grup);
			}
			if(isset($order)){
				$sql->orderBy($order);
			}
		return $sql->get($limit, $offset)->getResult();
	}

	public function bagian($limit=null, $offset=0)
	{
		return $this->builder->get($limit, $offset);
	}
	public function berdasarkan($id = null, $kondisi = null)
	{
		if (isset($kondisi)) {
			return $this->builder->getWhere($kondisi);
		} else {
			return $this->builder->getWhere([$this->pk => $id]);
		}
	}

	public function tertentu($where = null, $kolom = '*', $limit = null, $offset = 0, $grup='', $order='')
	{
		$query = $this->builder->select($kolom)->where($where);
			if(isset($grup)){
			$query->groupBy($grup);
			}
			if(isset($order)){
				$query->orderBy($order);
			}
		return $query->get($limit, $offset);
	}
	public function hitung(){
		return $this->builder->countAllResults();
	}
	
	public function join($tb = '', $fk = '', $tipe = 'INNER', $kolom = '*', $where = [], $limit = null, $offset = 0)
	{
		$join = $this->table . '.' . $this->pk . '=' . $tb .'.' . $fk;
		if (isset($where)) {
			$sql = $this->builder();
			$sql->select($kolom);
			$sql->join($tb, $join, $tipe);
			$sql->where($where);
		} else {
				$sql = $this->builder();
				$sql->select($kolom);
				$sql->join($tb, $join, $tipe);
				
		}
		return $sql->get($limit, $offset);
	}
	public function singleJoin($tb = '', $fk = '', $tipe = 'INNER', $kolom = '*', $where = [], $limit = null, $offset = 0)
	{
		$join = $this->table . ".". $this->pk . "=" . $tb ."." . $fk;
		if (isset($where)) {
			$sql = $this->builder();
			$sql->select($kolom);
			$sql->join($tb, $join, $tipe);
			$sql->where($where);
		} else {
				$sql = $this->builder();
				$sql->select($kolom);
				$sql->join($tb, $join, $tipe);
				
		}
		return $sql->get();
	}

	public function multiJoin($join = null, $kolom = '*', $where = null, $grup='', $order='')
	{
		/*
		* untuk melakukan join ke bnyk tabel maka 
		*harus join tersebut dalam bentuk array
		$join = [
						['tabel'=>'satu', 'kon'=>'satu.satu = dua.dua', 'tip'=>'inn'],
						
						
					];
		//$join = $this->table . '.id_' . $tb . '=' . $fk;
		*/

		if (isset($where)) {
			$sql = $this->builder();
			$sql->select($kolom);
			for ($i = 0; $i < count($join); $i++) {
				$sql->join($join[$i]['tabel'], $join[$i]['kon'], $join[$i]['tip']);
			}
			$sql->where($where);
			if(isset($grup)){
			$sql->groupBy($grup);
			}
			if(isset($order)){
				$sql->orderBy($order);
			}
			$query = $sql->get();
		} else {

			$sql = $this->builder();
			$sql->select($kolom);
			for ($i = 0; $i < count($join); $i++) {
				$sql->join($join[$i]['tabel'], $join[$i]['kon'], $join[$i]['tip']);
			}
			if(isset($grup)){
			$sql->groupBy($grup);
			}
			if(isset($order)){
				$sql->orderBy($order);
			}
			$query = $sql->get();
		}
		return $query;
	}

	public function ambilField()
	{
		return $this->db->getFieldNames($this->table);
	}
	
	public function ambilFieldTertentu($table)
	{
		return $this->db->getFieldNames($table);
	}
	
	public function setDataPengajuan($id_layanan=0, $id_pengajuan=null,$bulan='',$tahun='',$kode_opd='')
	{
		$id  = $this->generateId($id_layanan);
		if(!empty($id_pengajuan)){
			$id  = $id_pengajuan;
		}
		$data = array(
						'id_pengajuan'=>$id,
						'id_layanan'=>$id_layanan,
						'id_satuan_kerja'=>$kode_opd,
						'bulan'=>$bulan,
						'tahun'=>$tahun,
						'nip'=>session('id_pengguna'),
						'tanggal'=>date("Y-m-d H:i:s")
					);
		return $this->simpanTabelTertentu('pengajuan', $data);
	}
	
	public function cekPengajuan($id_layanan=0, $nip)
	{
		$data = $this->db->table('pengajuan')->getWhere(['id_layanan'=>$id_layanan, 'nip'=>$nip, 'is_complite'=> 0])->getResult();
		if($data){
			return false;
		}else{
			return true;
		}
	}
	
	public function generateId($id_layanan)
	{
		$jumlah = $this->db->table('pengajuan')->countAllResults() + 1; 
		return  $id_layanan . $jumlah . date('md').rand(1,500);
	}
	
	public function generateQuery($query)
	{
		return $this->db->query($query);
	}
	
	// function instan untuk dipakai
	
	public function simpanTabelTertentu($tabel, $data, $func='')
	{
		$this->status = $this->db->table($tabel)->insert($data);
		return $func . $this->pesan();
	}
	
	public function updateTabelTertentu($tabel, $pk, $val, $data, $func='')
	{
		$query = $this->db->table($tabel);
		return $query->where($pk, $val)->update($data);
		//$this->status = $query->where($pk, $val)->update($data);
		//return $func . $this->pesan();
	}
	
	public function hapusTabelTertentu($tabel, $pk, $val,$func='')
	{
		$query = $this->db->table($tabel);
		$this->status = $query->where($pk, $val)->delete();
		return $func . $this->pesan();
	}
	
	public function getTabelTertentu($tabel, $where=[], $limit = null, $offset = 0, $order='', $grup='', $select='*')
	{
		$query = $this->db->table($tabel)->select($select);
		if(!empty($where)){
			$query = $this->db->table($tabel)->select($select)->where($where);
		}
		if(isset($grup)){
			$query->groupBy($grup);
			}
		if(isset($order)){
			$query->orderBy($order);
		}
		return $query->get($limit, $offset);
	}
	
	public function hitungTertentu($tabel, $where=[]){
		
		if(isset($where)){
			$query = $this->db->table($tabel)
				->select('*')
				->where($where)
				->get();
			return $query->get();
		}else{
			return $this->db->table($tabel)->countAllResults();
		}
		
	}
	public function getLayanan($id){
		return $this->db->table('layanan')->getWhere(['id_layanan'=>$id])->getRow();
	}
	
	private function getIdInstansi($nip){
		$data = $this->db->table('buku_jabatan')->getWhere(['nip'=>$nip])->getRow();
		if($data->kode_satu == null){
			return false;
		}else{
			return $data->kode_satu;
		}
	}
}
