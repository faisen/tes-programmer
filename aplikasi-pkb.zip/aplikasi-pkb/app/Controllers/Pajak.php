<?php

namespace App\Controllers;
use App\Models\Dapur;

class Pajak extends BaseController
{
    public $model = '';
    public $pk_menu = '';
    public $id_data = '';
    public $id_sub_data = '';

    public function __construct()
    {
       helper('Fungsi_helper');
    }
    public function index()
    {
		$data['load_js'] = 'layanan/login.js';
		$data['kode_cap'] = '';
		return view('main/login', $data);
    }
	
	public function home(){
		$mdl = new Dapur(['table' => 'pkb', 'pk' => 'nopol']);
		$data['tagihan'] = $mdl->generateQuery('SELECT SUM(totaltagihan) AS jml, YEAR(tglntpd) AS tahun FROM pkb GROUP BY tglntpd')->getResult();
		$data['datamerek'] = $mdl->generateQuery('SELECT SUM(pnbp) AS jml, merkkendaraan FROM pkb GROUP BY merkkendaraan')->getResult();
       
		$data['judul'] = 'halaman beranda';
        $data['load_js'] = 'login.js';
        $data['content'] = 'main/dashboard';
		$data['row'] =[];
        return view('main/beranda', $data);
	}
	
	
	public function input($tipe=true){
		$mdl = new Dapur(['table' => 'pkb', 'pk' => 'nopol']);
		$data = $mdl->ambilField();
		if($tipe){
		$data['judul'] = 'Tambah Data';
        $data['load_js'] = 'login.js';
        $data['content'] = 'pkb/input';
		$data['data'] =$data;
        return view('main/beranda', $data);
		}else{
			$input =array();
			foreach ($data as $r){
				$input[$r] = $this->request->getPost($r);
			}
			$mdl->simpan($input, "Input data");
			return redirect()->to(base_url('pajak/getData'));
		}
	}
	
	public function getData(){
		
		$mdl = new Dapur(['table' => 'pkb', 'pk' => 'nopol']);
		$data['judul'] = 'halaman beranda';
        $data['load_js'] = 'login.js';
        $data['content'] = 'pkb/list';
		$data['data'] =$mdl->semua();
        return view('main/beranda', $data);
	}
	
	public function rincian($nopol, $tipe= 'view'){
		
		$mdl = new Dapur(['table' => 'pkb', 'pk' => 'nopol']);
		$row =$mdl->ambilField();
		$data['judul'] = 'Rincian data PKB NOPOL : '.decrypt($nopol);
        $data['load_js'] = 'login.js';
        $data['content'] = 'pkb/rincian';
        $data['field'] = $row;
		$data['row'] =$mdl->tertentu(['nopol'=>decrypt($nopol)], '*')->getRowArray();
		//print_r($data['field']);
        return view('main/beranda', $data);
	}
	
	public function edit($nopol, $tipe= 'view'){
		
		$mdl = new Dapur(['table' => 'pkb', 'pk' => 'nopol']);
		$row =$mdl->ambilField();
		if($tipe == 'view'){
		$data['judul'] =  'Ubah Data PKB NOPOL : '.decrypt($nopol);
        $data['load_js'] = 'login.js';
        $data['content'] = 'pkb/edit';
        $data['field'] = $row;
		$data['row'] =$mdl->tertentu(['nopol'=>decrypt($nopol)], '*')->getRowArray();
		//print_r($data['field']);
        return view('main/beranda', $data);
		}else{
			$input=array();
			foreach($row as $r){
				$input[$r] = $this->request->getPost($r);
				$cek =  $mdl->ubah($this->request->getPost('nopol'), $input, 'Ubah data');
			}
			return redirect()->to(base_url('pajak/getData'));
		}
	}
	
	public function hapus($nopol){
		$mdl = new Dapur(['table' => 'pkb', 'pk' => 'nopol']);
		$mdl->hapus(decrypt($nopol), 'Hapus Data');
		return redirect()->to(base_url('pajak/getData'));
	}
	
	public function generateData(){
		$mdl = new Dapur(['table' => 'pkb', 'pk' => 'nopol']);
		
		$dataJson = json_decode(file_get_contents('https://samsat.bengkuluprov.go.id/pkb_dummy_data.json'),true);
		
		for($i=0; $i< sizeof($dataJson); $i++){
	$dataIpunt['nopol'] = $dataJson[$i]['Nopol'];
	$dataIpunt['kodewilayah'] = $dataJson[$i]['KodeWilayah'];
	$dataIpunt['namawp'] = $dataJson[$i]['NamaWp'];
	$dataIpunt['alamatwp'] = $dataJson[$i]['AlamatWp'];
	$dataIpunt['jeniskendaraan'] = $dataJson[$i]['JenisKendaraan'];
	$dataIpunt['tipekendaraan'] = $dataJson[$i]['TipeKendaraan'];
	$dataIpunt['warnakendaraan'] = $dataJson[$i]['WarnaKendaraan'];
	$dataIpunt['tahunbuatan'] = $dataJson[$i]['TahunBuatan'];
	$dataIpunt['nomorrangka'] = $dataJson[$i]['NomorRangka'];
	$dataIpunt['nomormesin'] = $dataJson[$i]['NomorMesin'];
	$dataIpunt['pkbpokok'] = $dataJson[$i]['PkbPokok'];
	$dataIpunt['pkbtunggakan'] = $dataJson[$i]['PkbTunggakan'];
	$dataIpunt[strtolower('PkbDenda')] = $dataJson[$i]['PkbDenda'];
	$dataIpunt[strtolower('TglAwal')] = $dataJson[$i]['TglAwal'];
	$dataIpunt[strtolower('TglAkhir')] = $dataJson[$i]['TglAkhir'];
	$dataIpunt['status'] = $dataJson[$i]['Status'];
	$dataIpunt['pnbp'] = $dataJson[$i]['Pnbp'];
	$dataIpunt['tglntpd'] = $dataJson[$i]['TglNtpd'];
	$dataIpunt['totaltagihan'] = $dataJson[$i]['TotalTagihan'];
	$dataIpunt['swdklljpokok'] = $dataJson[$i]['SwdklljPokok'];
	$dataIpunt['SwdklljDenda'] = $dataJson[$i]['SwdklljDenda'];
	$dataIpunt['merkkendaraan'] = $dataJson[$i]['MerkKendaraan'];
		$cek = $mdl->simpan($dataIpunt, 'input data');
		}
		//print_r($dataJson);
	}

   
}
