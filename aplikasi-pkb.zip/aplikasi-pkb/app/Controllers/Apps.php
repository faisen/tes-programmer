<?php

namespace App\Controllers;
use App\Models\Dapur;

class Apps extends BaseController
{
    public $model = '';
    public $pk_menu = '';
    public $id_data = '';
    public $id_sub_data = '';

    public function __construct()
    {
       
    }

    public function index()
    {
		//
		
    }
	
	public function cekLogin()
	{
		$mdl = new Dapur(['table' => 'authuser', 'pk' => 'id_auth']);
		$pesan=[];
		if($this->cekCaptcha($this->request->getPost('kode_cap'))){
			$data = $mdl->tertentu(['id_pegawai'=>$this->request->getPost('nama_pengguna')], '*')->getRow();
			if($data){
				if(password_verify($this->request->getPost('kata_sandi'), $data->kata_sandi)){
					$id_pengguna = $data->id_pegawai;
					$nama_pengguna = $data->nama_pengguna;
					$tipe_pengguna = $data->tipe_pengguna;
					$level = $data->level;
					$session = array(
						'id_pengguna' => $id_pengguna,
						'nama_pengguna' => $nama_pengguna,
						'level'=>$level,
						'tipe_pengguna'=>$tipe_pengguna,
					);
					$this->ses->set($session);
					// $agent = $this->getUserAgent();
					// $array = array(
									// 'id_pengguna'=>$id_pengguna,
									// 'browser'=>$agent['agent'],
									// 'perangkat'=>$agent['platform'],
									// 'ip_addr'=>$_SERVER['REMOTE_ADDR'],
									// 'waktu'=>waktu(),
									// 'status'=>1
								// );
					//$setDataLog = $this->setDataLogin($id_pengguna, $array, $tipe_pengguna);
					//if($setDataLog){
						$pesan = ['status'=>true, 'pesan'=> "Login Berhasil"];
					//}else{
						//return $this->historyLogin();
					//}
					
				}else{
					$pesan = ['status'=>false, 'pesan'=> "Password dan username tidak cocok"];
				}
			}else{
					$pesan = ['status'=>false, 'pesan'=> "Akun tidak ditemukan"];
				}
		
		}else{
				$pesan = ['status'=>false, 'pesan'=> "Kode Captcha Salah!"];
			}
		return $this->response->setJSON($pesan);
	}
	
	public function keluar($kondisi = false)
	{
		$this->ses->destroy();
		return redirect()->to(base_url());
	} 
	
   
}
