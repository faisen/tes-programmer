$('#btn-simpan').hide();  
$('#diclaim').click(function(){
	if($(this).prop("checked") == true){
		$('#btn-simpan').show();
	}else{
		$('#btn-simpan').hide();  
	}
});

var id_pengajuan = $('#id_pengajuan').val();  
var kode_opd = $('#kode_opd').val();  
berkasLampiran();
function berkasLampiran(){
	
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var request = $.ajax({
        url: baseUrl+'/permohonan/getSyaratLampiran/'+kode_opd+'/'+id_pengajuan,
        method: "POST",
        dataType: "JSON",
		beforeSend: function() {
			$(".loaderMenu").html('<div class="spinner-border text-danger" style="width: 3rem; height:3rem;"role="status"><span class="sr-only">Loading...</span></div>');
		}
	});
	request.done(function( data ) {
		
		var no =1;
        var viewHtml='';
		var path ='';
		''
			for(var i=0; i<data.length; i++){
				path = data[i].nama_file;
				viewHtml +='<tr>'+
				'<td>'+ no++ +'</td>'+
				'<td>'+ data[i].nip +'</td>'+
				'<td>'+ data[i].nama +'</td>'+
				'<td><button class="btn btn-primary btn-xs" onClick="openNewFile('+"'"+path+"'"+')">Buka</button></td>'+
				'<td>'+getStatusBerkas(data[i].status)+'</td>' +
				'<td><button class="btn btn-danger btn-xs" onClick="tundaLampiran(11,'+data[i].id_berkas_lampiran+')">perbaikan</button></td>' +
				'</tr>';
			}
			$( "#tampilBerkasLampiran" ).html( viewHtml );
	});
	 
	request.fail(function( jqXHR, textStatus ) {
	  swal("Dibatalkan", "Terjadi kesalahan :)", "error"); 
	  $(".spinner-border").remove();
	});
	
	
}

function perbaikan(tipe, id_data){
	if(tipe ==11){
		$('#showFormPerbaikan').modal('show');
		$('#id_berkas_syarat').val(id_data);
	}else{
	
		var dataPost = $('#formPerbaikanBerkas').serialize();
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		var request = $.ajax({
			url: baseUrl+'/permohonan/perbaikan/',
			method: "POST",
			dataType: "JSON",
			data:dataPost,
			beforeSend: function() {
				$(".loaderMenu1").html('<div class="spinner-border text-danger" style="width: 3rem; height:3rem;"role="status"><span class="sr-only">Loading...</span></div>');
			}
		});
		request.done(function( data ) {
			if(data.status){
				setTimeout(function(){
					swal("Berhasil!", "pesan : "+data.pesan, "success");
					location.reload();
				}, 500);
			}
		});
		 
		request.fail(function( jqXHR, textStatus ) {
		  swal("Dibatalkan", "Terjadi kesalahan :)", "error"); 
		  $(".spinner-border").remove();
		});
	
	}
}

function tunda(level){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	swal({   
			title: "Dikembalikan / di rollback ke pemohon?",   
			text: "Apakah anda yakin Permohonan ini akan dikembalikan / di rollback ke pemohon?",   
			icon: "warning",   
			dangerMode: true,  
			buttons: true,	
			closeOnClickOutside: false,			
		}).then(function(isConfirm){
			if (isConfirm) {     
				var dataPost = $('#formVerifikasi').serialize();
				var request = $.ajax({
				  url: baseUrl + "/permohonan/tunda/"+level+"/"+kode_opd+"/"+id_pengajuan,
				  method: "POST",
				  data: dataPost,
				  dataType: "JSON"
				});
				 
				request.done(function( data ) {
					if(!data.Error){
						swal("Berhasil!", "Status: "+data.pesan, "success");
						location.replace(data.link);
					}
				});
				 
				request.fail(function( jqXHR, textStatus ) {
				  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
				});
			}
		});
}

function verifikasi(level){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	swal({   
			title: "Lanjutkan ke tahap selanjutnya?",   
			text: "Apakah anda yakin Permohonan ini akan lanjutkan ke tahap selanjutnya?",   
			icon: "warning",   
			dangerMode: true,  
			buttons: true,	
			closeOnClickOutside: false,			
		}).then(function(isConfirm){
			if (isConfirm) {     
				var dataPost = $('#formVerifikasi').serialize();
				var request = $.ajax({
				  url: baseUrl + "/permohonan/tunda/"+level+"/"+kode_opd+"/"+id_pengajuan,
				  method: "POST",
				  data: dataPost,
				  dataType: "JSON"
				});
				 
				request.done(function( data ) {
					if(!data.Error){
						swal("Berhasil!", "Status: "+data.pesan, "success");
						location.replace(data.link);
					}
				});
				 
				request.fail(function( jqXHR, textStatus ) {
				  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
				});
			}
		});
}

function tundaLampiran(tipe, id_data){
	if(tipe ==11){
		$('#formPerbaikanLampiran').modal('show');
		$('#id_berkas_lampiran').val(id_data);
	}else{
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		swal({   
				title: "Lampiran ini akan dikembalikan ke pemohon?",   
				text: "Apakah anda yakin Permohonan ini akan dikembalikan / di rollback ke pemohon?",   
				icon: "warning",   
				dangerMode: true,  
				buttons: true,	
				closeOnClickOutside: false,			
			}).then(function(isConfirm){
				if (isConfirm) {     
					var dataPost = $('#perbaikanBerkasLampiran').serialize();
					var request = $.ajax({
					  url: baseUrl + "/permohonan/tundaLampiran/1/"+kode_opd+"/"+id_pengajuan,
					  method: "POST",
					  data: dataPost,
					  dataType: "JSON"
					});
					 
					request.done(function( data ) {
						if(!data.Error){
							setTimeout(function(){
								swal("Berhasil!", "pesan : "+data.pesan, "success");
								berkasLampiran();
							}, 500);
						}
					});
					 
					request.fail(function( jqXHR, textStatus ) {
					  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
					});
				}
			});
	}
}

function getStatusBerkas(sts){
	if(sts == 1){
		return '<span class="label label-success">OK</span>';
	}else{
		return '<span class="label label-danger">Ditolak</span>';
	}
}
