
function tampilLaporan(){
	// var bulan = $('#bulan').val();
	// var notaris = $('#notaris').val();
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	$.ajax({
		type:'POST',
		url:baseUrl+'/laporan/getReport',
		dataType:'HTML',
		data:{bulan:$('#bulan').val(), notaris:$('#notaris').val(), id_layanan:$('#id_layanan').val(), tahun:$('#tahun').val()},
		success: function(data){
			$('#tampilTabelLaporan').html(data);
		}
	});
}

function draw_data(data){
	var baris='';
	var no=0;
	for(var i=0; i<data.length; i++){
		no = ++no;
		baris +='<tr>'
				+'<td>'+ no +'</td>'+
				'<td>'+data[i].bulan+ '</td>' +
				'<td>'+data[i].tahun+ '</td></tr>';
	}
	$('#tampilDataLaporan').html(baris);
}

function buatPaging(response){
	  var data_paging = $('#paging_page');
	  var result_page = '';

	  if(response.total_page > 1){
	   result_page += '<ul class="pagination justify-content-center">';

	   if(response.page > (response.prev + 1)){
		result_page += '<li class="page-link"><a href="javascript:showAkta(1)">first</a></li>';
		result_page += '<li class="page-link"><a href="javascript:showAkta('+ (response.page - 1) +')">prev</a></li>';
	   }

	   for(var i=response.start_page; i<=response.display_page; i++){
		if(i == response.page){
		 result_page += '<li class="page-link"><a href="#'+ i +'">'+ i +'</a></li>';
		}else{
		 result_page += '<li class="page-link"><a href="javascript:showAkta('+ i +')">'+ i +'</a></li>';
		}
	   }

	   if(response.total_page > response.display_page){
		result_page += '<li class="page-link"><a href="javascript:showAkta('+ (response.page + 1) +')">next</a></li>';
		result_page += '<li class="page-link"><a href="javascript:showAkta('+ response.total_page +')">last</a></li>';
	   }

	   result_page += '</ul>';
	  }

	  data_paging.html(result_page);
}

function tampilRekap(){
	// var bulan = $('#bulan').val();
	// var notaris = $('#notaris').val();
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var dataPost = $("#formRekap").serialize();
	$.ajax({
		type:'POST',
		url:baseUrl+'/laporan/rekap/0',
		dataType:'HTML',
		data:dataPost,
		success: function(data){
			$('#tampilRekap').html(data);
		}
	});
}
	