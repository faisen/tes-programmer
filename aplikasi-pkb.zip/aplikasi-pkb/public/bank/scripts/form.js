//tampilDataForm(id_menu_app);
const formLayanan = document.querySelector("#tambahFormLayanan"),
		tombolSimpanForm = formLayanan.querySelector("#submitForm"),
		Pesanerror = formLayanan.querySelector("#pesan"),
		id_menu_app = formLayanan.querySelector("#id_menu_app");
		let tomboledit = document.querySelector("#tombolEdit");
		
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		formLayanan.onsubmit = (e)=>{
			e.preventDefault();
		}
		
		tombolSimpanForm.onclick = ()=>{
			var dataPost = $("#tambahFormLayanan").serialize();
				var request = $.ajax({
					url: baseUrl + "/apps/tambahForm/0/" + id_menu_app,
					method: "POST",
					dataType: "JSON",
					data:dataPost
				});
				
				request.done(function( data ) {
					if(data.status){
						setTimeout(function(){
							swal("Berhasil!", "pesan : "+data.pesan, "success");
							location.reload();
						}, 500);
					}
				});
				
				request.fail(function( jqXHR, textStatus ) {
					swal("Error", "Kesalahan koneksi :"+textStatus, "error"); 
				});
		}
function tambahData(id_menu_app){
	getField(id_menu_app);
	$('#modalTambahFormLayanan').modal('show');
}

function getField(id_menu_app){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var request = $.ajax({
		url: baseUrl + "/apps/getField/"+id_menu_app,
		method: "POST",
		dataType: "JSON"
	});
	
	request.done(function( data ) {
		for (let i = 0; i < data.length; i++) {
			$('#nama').append($("<option></option>").attr("value", data[i]).text(data[i])); 
		}
	});
	
}	

function editData(id_form) {
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	
	var request = $.ajax({
			url: baseUrl + "/apps/getIdForm/" + id_form,
			method: "POST",
			dataType: "JSON"
		});
		
		request.done(function( data ) {
			getField(data.id_menu_app);
			$('#id_form').val(id_form);
			$('#edit').val(1);
			$('#nama').val(data.nama);
			$('#label').val(data.label);
			$('#id').val(data.id);
			$('#tipe').val(data.tipe);
			$('#kelas').val(data.kelas);
			$('#konten').val(data.konten);
			$('#tag').val(data.tag);
			$('#pesan').val(data.pesan);
			$('#wajib').val(data.wajib);
			$('#status').val(data.status);
			$('#id_menu_app').val(data.id_menu_app);
			$('#dropdown').val(data.dropdown);
			$('#modalTambahFormLayanan').modal('show');
			
		});
}

function hapusData(id_form) {
	swal({   
			title: "Apakah anda yakin?",   
			text: "Data ini akan dihapus secara permanen!",   
			icon: "warning",   
			dangerMode: true,  
			buttons: true,	
			closeOnClickOutside: false,			
		}).then(function(isConfirm){
			if (isConfirm) { 
				var getUrl = window.location;
				var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
				var request = $.ajax({
					url: baseUrl + "/apps/hapusForm/"+id_form,
					method: "POST",
					dataType: "JSON"
				});
				
				request.done(function( data ) {
					swal("Berhasil!", "pesan : "+data.pesan, "success");
					location.reload();
				});
			}
		});
}
function tutup() {
	$('#ubahDataNotaris').hide();
	$('#dataProfilNotaris').show();
}