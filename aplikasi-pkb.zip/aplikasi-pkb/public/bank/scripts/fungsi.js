<script src="<?php echo base_url()?>assets/scripts/jquery.min.js"></script>
	<script type="text/javascript">
        $(document).ready(function(){
          
			$("#kecamatan").change(function (){
                var url = "<?php echo site_url('user/logincontrol/add_ajax_des');?>/"+$(this).val();
                $('#kelurahan').load(url);
                return false;
            })
        });
		
	function simpanData(){
		var jnsPermohonan =$("[name ='jnsPermohonan']").val();
		var stra =$("[name ='stra']").val();
		var tglStra =$("[name ='tglStra']").val();
		var kerja =$("[name ='kerja']").val();
		var tmpt =$("[name ='tempat']").val();
		var srn =$("[name ='sarana']").val();
		var lok1 =$("[name ='lokasi']").val();
		var lok2 =$("[name ='lokasi1']").val();
		var lok3 =$("[name ='lokasi2']").val();
		var kec =$("[name ='kecId']").val();
		var kel =$("[name ='kelId']").val();
		
		$.ajax({
			type: 'POST',
			data : 'permohonan ='+permohonan+'&str='+str+'&tglStr='+tglStr+'&krj='+krj+'&tmpt='+tmpt+'&srn='+srn+'&lok1='+lok1+'&lok2='+lok2+'&lok3='+lok3+'&kel='+kel+'&kec='+kec,
			url :'<?php echo base_url()."izin/Sipacontrol/simpan" ?>',
			dataType: 'json',
			success: function(hasil){
				$("#pesan").html(hasil.pesan);
			}
		});
	}
    </script>