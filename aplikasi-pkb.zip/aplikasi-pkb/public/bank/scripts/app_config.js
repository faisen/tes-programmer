function addModul(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var folder ='';
	var field ='';
	
	var dataPost = $("#formModul").serialize();
	var request = $.ajax({
		 url:baseUrl + "/apps/addModul",
		 type:"post",
		 data:dataPost
    });
	
    request.done(function( data ) {
        if(data.status == true){	
			setTimeout(function(){
				swal("Berhasil!", "pesan : "+data.pesan, "success");
				location.reload();
			}, 1000);
        }
        else{
            swal("Gagal", "Status : " +data.pesan, "error");  
        }
    });
        
    request.fail(function( jqXHR, textStatus ) {
        swal("Dibatalkan", "Aksi dibatalkan :) Status : " + textStatus, "error");  
    });
}

function editModul(){
	var formActionEdit = $("#formModulEdit").attr("action");
	var dataPost = $("#formModulEdit").serialize();
	var request = $.ajax({
		 url:formActionEdit,
		 type:"post",
		 data:dataPost
    });
	
    request.done(function( data ) {
        if(data.status == true){	
			setTimeout(function(){
				swal("Berhasil!", "pesan : "+data.pesan, "success");
				mundur();
			}, 1000);
        }
        else{
            swal("Gagal", "Status : " +data.pesan, "error");  
        }
    });
        
    request.fail(function( jqXHR, textStatus ) {
        swal("Dibatalkan", "Aksi dibatalkan :) Status : " + textStatus, "error");  
    });
}

function hapusModul(id_menu){
	swal({   
		title: "Apakah anda yakin?",   
		text: "Data ini akan dihapus secara permanen!",   
		icon: "warning",   
		dangerMode: true,  
		buttons: true,	
		closeOnClickOutside: false,			
	}).then(function(isConfirm){
		if (isConfirm) {
			var getUrl = window.location;
			var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

			var request = $.ajax({
				url: baseUrl + "/apps/hapus/" + id_menu,
				method: "POST",
				dataType: "JSON",
			});

			request.done(function( data ) {
				if(data.status){
					setTimeout(function(){
						swal("Berhasil!", "pesan : "+data.pesan, "success");
						location.reload();
					}, 500);
				}
			});
			request.fail(function( jqXHR, textStatus ) {
				swal("Error", "Kesalahan saat tambah data :"+textStatus, "error"); 
			});
		}
	});
}
function cariData(){
	var id_menu_app =  $('#id_menu_app').val();
	var jenis_data = $('#jenis_data').val();
	var nilai = $('#val').val();
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	if(nilai ==''){
		swal("Warning", "Harap masukan kata kunci pencarian", "warning"); 
	}else{
		var dataPost = $("#formCariData").serialize();
			var request = $.ajax({
				url: baseUrl + "/getter/cari/",
				method: "POST",
				dataType: "HTML",
				data:dataPost,
				beforeSend: function() {
					load(300);
				}
			});
			
			request.done(function( data ) {
				$('.hasilPencarian').show();
				$('#tampilHasilPencarian').html(data);
			});
			
			request.fail(function( jqXHR, textStatus ) {
				swal("Error", "Terjadi Kesalahan :"+textStatus, "error"); 
			});
	}
		
}

function simpanDataForm(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var folder ='';
	var field ='';
	
	var dataPost = $("#formApp").serialize();
	var request = $.ajax({
		 url:baseUrl + "/setter/inputFromModal",
		 type:"post",
		 data:dataPost
    });
	
    request.done(function( data ) {
        if(data.status == true){	
			setTimeout(function(){
				swal("Berhasil!", "pesan : "+data.pesan, "success");
				location.reload();
			}, 1000);
        }
        else{
            swal("Gagal", "Status : adadada" , "error");  
        }
    });
        
    request.fail(function( jqXHR, textStatus ) {
        swal("Dibatalkan", "Aksi dibatalkan :) Status : " + textStatus, "error");  
    });
}


function hapusData(pkTabelValue) {
	swal({   
			title: "Apakah anda yakin?",   
			text: "Data ini akan dihapus secara permanen!",   
			icon: "warning",   
			dangerMode: true,  
			buttons: true,	
			closeOnClickOutside: false,			
		}).then(function(isConfirm){
			if (isConfirm) { 
				var getUrl = window.location;
				var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
				var request = $.ajax({
					url: baseUrl + "/setter/delete/"+pkTabelValue,
					method: "POST",
					dataType: "JSON",
					data:{id_menu_app : $('#id_menu_app').val()}
				});
				
				request.done(function( data ) {
					swal("Berhasil!", "pesan : "+data.pesan, "success");
					location.reload();
				});
			}
		});
}

function unggahFilePendukung(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var dataPost = $("#formApp").serialize(); 
	var files = $('#nama_file')[0].files;
	var id_layanan = $('#id_menu_app').val();
	var fd = new FormData();
	fd.append('nama_file',files[0]);
	var request = $.ajax({
		 url:baseUrl + '/setter/unggahFile/1/'+id_layanan,
		 type:"post",
		 data:fd,
		 contentType: false,
		 processData: false,
		 dataType: 'json',
    });
    
    request.done(function( data ) {
        if(data.status == true){
			var path=baseUrl+'/'+data.nama+'';
			var wrapper = $('.tombol');
			var fieldHTML = '<button class="btn btn-danger btn-xs" type="button" onClick="hapusFileLoad()"><span class="lnr lnr-trash"></span></button> | <button type="button" class="btn btn-success btn-xs"  onclick="openNewFile('+"'"+path+"'"+')"><span class="lnr lnr-enter"></span></button>';
			$(wrapper).append(fieldHTML);
            swal("Berhasil!", "Status : " +data.pesan, "success");	
			 $('#nama_file_baru').val(data.nama);
			 $('.btn-file').hide();
			 $(".tampilFilePendukung").show();
			 
        }else{
            swal("Gagal", "Status : " +data.pesan, "error");  
        }
       // window.location.href = baseUrl+$('#linkIndex').val()
    });
        
    request.fail(function( jqXHR, textStatus ) {
        swal("Dibatalkan", "Aksi dibatalkan :) Status : " + textStatus, "error");  
    });
}


function hapusFileLoad(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var request = $.ajax({
		url: baseUrl + "/setter/hapusFileTemp/",
		method: "POST",
		dataType: "JSON",
		data:{file_temp : $('#nama_file_baru').val()}
	});
	
	request.done(function( data ) {
		swal("Berhasil!", data.pesan, "success");
		$('.btn-file').show();
		$(".tampilFilePendukung").hide();
	});
	request.fail(function( jqXHR, textStatus ) {
        swal("Dibatalkan", "Aksi dibatalkan :) Status : " + textStatus, "error");  
    });
	
}
function gantiFileLoad(){
	
	$(".tampilGanti").show();
	$(".tampilFileAsli").hide();
}
function lihatFileAsli(){
	
	$(".tampilGanti").hide();
	$(".tampilFileAsli").show();
}