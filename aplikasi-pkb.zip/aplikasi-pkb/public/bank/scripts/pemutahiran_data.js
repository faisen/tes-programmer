var id_instansi =  $('#id_instansi').val();
const form = document.querySelector("#formMutasi"),
	continueBtn = form.querySelector("#submit");
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	form.onsubmit = (e)=>{
		e.preventDefault();
	}
	
	continueBtn.onclick = ()=>{
		var dataPost = $("#formMutasi").serialize();
		var request = $.ajax({
			url: baseUrl +"/pemutahiran/simpanUpdate/"+id_instansi,
			method: "POST",
			dataType: "JSON",
			data:dataPost
		});
		
		request.done(function( data ) {
			if(!data.Error){
				swal("Berhasil!",data.statusUnor+", "+data.statusUnor, "success");
				setTimeout(function(){
					location.replace(baseUrl + "/pemutahiran/mutasi"+data.id_instansi);
				}, 1000);
			}else{
				swal("Gagal!", "pesan : Harap cek kembali", "error");
			}
		});
		
		request.fail(function( jqXHR, textStatus ) {
			swal("Error", "Kesalahan koneksi : "+textStatus, "error"); 
		});
	}
function pindah(tipe=1, nip=''){
	
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	if(tipe ==1){
		swal({   
				title: "Apakah anda yakin?",   
				text: "Pastikan bahwa pegawai " + nip + " tidak dinas di OPD ini lagi!",   
				icon: "warning",   
				dangerMode: true,  
				buttons: true,	
				closeOnClickOutside: false,			
			}).then(function(isConfirm){
				if (isConfirm) {
				var request = $.ajax({
						url: baseUrl + "/pemutahiran/getJabatan/100/"+nip,
						method: "GET",
						dataType: "JSON",
					});
					
					request.done(function( resp ) {
						
						$('#nama').val(resp.nama);
						$('#jabatan_sekarang').val(resp.jabatan);
					});
					$('#nip').val(nip);
					$('#showModalPindah').modal('show');
				}
			});	
	}else{
		var request = $.ajax({
					url: baseUrl + "/pemutahiran/pindahOpd/"+id_instansi+"/"+nip,
					method: "POST",
					dataType: "HTML",
					beforeSend: function() {
						
					}
				});
				
				request.done(function( data ) {
					
					$('#TampilData').html(data);
				});
				
				request.fail(function( jqXHR, textStatus ) {
					swal("Error", "Terjadi Kesalahan :"+textStatus, "error"); 
				});
	}
}

function getJabatan(){
	var id_opd = $('#opd_tujuan').val();
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

		var request = $.ajax({
			url: baseUrl + "/pemutahiran/getJabatan/"+id_opd,
			method: "GET",
			dataType: "JSON",
		});
		
		request.done(function( data ) {
				var opsi='';
			if(!data.Error){
				for(var i=0; i<data.length; i++){
					opsi +='<option value="'+data[i].kode+'" >'+data[i].nama+'</option>';
				}
			}
			$('#jabatan_tujuan').html(opsi);
		});
		
}
	
function simpanMutasi(){
	var id_opd = $('#id_instansi').val();
	var dataPost = $("#formMutasi").serialize();
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

		var request = $.ajax({
			url: baseUrl + "/pemutahiran/simpanUpdate/"+id_opd,
			method: "POST",
			data:dataPost,
			dataType: "JSON",
		});
		
		request.done(function( data ) {
			if(!data.Error){
				swal("Berhasil!",data.statusUnor+", "+data.statusUnor, "success");
				setTimeout(function(){
					location.replace(baseUrl + "/pemutahiran/mutasi"+data.id_instansi);
				}, 1000);
			}
		});
		
}

function tutupMenu(){
	//$('#TampilData').hide();
	$('.loadData').hide();
}

