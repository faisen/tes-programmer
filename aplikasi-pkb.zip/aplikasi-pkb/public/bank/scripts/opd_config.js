var id_instansi =  $('#id_instansi').val();

function JabatanKosong(){
	
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

		var request = $.ajax({
			url: baseUrl + "/opd/jabatanKosong/view/"+id_instansi,
			method: "POST",
			dataType: "HTML",
			beforeSend: function() {
				
			}
		});
		
		request.done(function( data ) {
			$('.loadData').show();
			$('#TampilData').html(data);
		});
		
		request.fail(function( jqXHR, textStatus ) {
			swal("Error", "Terjadi Kesalahan :"+textStatus, "error"); 
		});
		
}

function pensiun(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

		var request = $.ajax({
			url: baseUrl + "/opd/pensiun/view/"+id_instansi,
			method: "POST",
			dataType: "HTML",
			beforeSend: function() {
				load(300);
			}
		});
		
		request.done(function( data ) {
			$('.loadData').show();
			$('#TampilData').html(data);
		});
		
		request.fail(function( jqXHR, textStatus ) {
			swal("Error", "Terjadi Kesalahan :"+textStatus, "error"); 
		});
}

function bukuJabatan(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

		var request = $.ajax({
			url: baseUrl + "/opd/bukuJabatan/"+id_instansi,
			method: "POST",
			dataType: "HTML",
			beforeSend: function() {
				load(300);
			}
		});
		
		request.done(function( data ) {
			$('.loadData').show();
			$('#TampilData').html(data);
		});
		
		request.fail(function( jqXHR, textStatus ) {
			swal("Error", "Terjadi Kesalahan :"+textStatus, "error"); 
		});
}

function statistik(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

		var request = $.ajax({
			url: baseUrl + "/opd/statistik/"+id_instansi,
			method: "POST",
			dataType: "HTML",
			beforeSend: function() {
				load(300);
			}
		});
		
		request.done(function( data ) {
			$('.loadData').show();
			$('#TampilData').html(data);
		});
		
		request.fail(function( jqXHR, textStatus ) {
			swal("Error", "Terjadi Kesalahan :"+textStatus, "error"); 
		});
}

function tutupMenu(){
	//$('#TampilData').hide();
	$('.loadData').hide();
}

