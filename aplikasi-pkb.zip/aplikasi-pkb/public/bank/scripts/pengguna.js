
function simpan(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var dataPost = $("#formPengguna").serialize();
	var request = $.ajax({
	  url: baseUrl + "/masuk/pengguna/add",
	  method: "POST",
	  data: dataPost,
	  dataType: "JSON"
	});
	 
	request.done(function( data ) {
		if(!data.Error){
			swal("Berhasil!", "Status: "+data.pesan, "success");
			location.reload();
		}
	});
	 
	request.fail(function( jqXHR, textStatus ) {
	  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
	});
}

function update(id_auth){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var dataPost = ""
	var request = $.ajax({
	  url: baseUrl + "/masuk/pengguna/update/"+id_auth+"/",
	  method: "POST",
	  data: dataPost,
	  dataType: "JSON"
	});
	 
	request.done(function( data ) {
		if(!data.Error){
			$("#u_nama_pengguna").val(data.nama_pengguna);
			$("#kata_sandi_lama").val(data.kata_sandi);
			$("#u_level").val(data.level);
			$("#u_status").val(data.status);
			$("#id_auth").val(data.id_auth);
			$("#showModalUpdatePengguna").modal('show');
		}
	});
	 
	request.fail(function( jqXHR, textStatus ) {
	  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
	});
}
function simpanUpdate(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var id_auth = $("#id_auth").val();
	var dataPost = $("#formUpdatePengguna").serialize();
	var request = $.ajax({
	  url: baseUrl + "/masuk/pengguna/add/"+id_auth+"/update",
	  method: "POST",
	  data: dataPost,
	  dataType: "JSON"
	});
	 
	request.done(function( data ) {
		if(!data.Error){
			swal("Berhasil!", "Status: "+data.pesan, "success");
			location.reload();
		}
	});
	 
	request.fail(function( jqXHR, textStatus ) {
	  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
	});
}
function hapus(id_auth){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	swal({   
			title: "Data ini akan dihapus, apakah anda yakin?",   
			text: "Data ini akan dihapus secara permanen!",   
			icon: "warning",   
			dangerMode: true,  
			buttons: true,	
			closeOnClickOutside: false,			
		}).then(function(isConfirm){
			if (isConfirm) {     
				
				var request = $.ajax({
				  url: baseUrl +"/masuk/pengguna/delete/"+id_auth,
				  method: "POST",
				  dataType: "JSON"
				});
				 
				request.done(function( data ) {
					if(!data.Error){
						swal("Berhasil!", "Status: "+data.pesan, "success");
						location.reload();
					}
				});
				 
				request.fail(function( jqXHR, textStatus ) {
				  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
				});
			}
		});
}


