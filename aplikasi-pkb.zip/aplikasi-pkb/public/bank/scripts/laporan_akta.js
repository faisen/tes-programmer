
const formLaporanAkta = document.querySelector("#formLaporanAkta"),
		tombolSimpanAkta = formLaporanAkta.querySelector("#submitLaporanAkta");
		
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		formLaporanAkta.onsubmit = (e)=>{
			e.preventDefault();
		}
		
		tombolSimpanAkta.onclick = ()=>{
			var dataPost = $("#formLaporanAkta").serialize();
				var request = $.ajax({
					url: baseUrl + "/laporan/inputLaporan",
					method: "POST",
					dataType: "JSON",
					data:dataPost
				});
				
				request.done(function( data ) {
					if(data.status){
						setTimeout(function(){
							swal("Berhasil!", "pesan : "+data.pesan, "success");
							location.reload();
						}, 500);
					}
				});
				
				request.fail(function( jqXHR, textStatus ) {
					swal("Error", "Terjadi Kesalahan :"+textStatus, "error"); 
				});
		}
showAkta(1);

function showAkta(page){
	var id_layanan = $('#id_layanan').val();
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	$.ajax({
		type:'GET',
		url:baseUrl+'/laporan/getDataJson/'+id_layanan+'/'+page,
		dataType:'JSON',
		success: function(data){
			draw_data(data.akta);
			buatPaging(data.paging);
			//console.log(data.akta);
		}
	});
}

function draw_data(data){
	var baris='';
	var no=0;
	for(var i=0; i<data.length; i++){
		no = ++no;
		// var penghadap = data[i].nama_penghadap
		// var strSplit = penghadap.split(",");
		baris +='<tr>'
				+'<td>'+ no +'</td>'+
				'<td>'+data[i].nomor_akta+ '</td>' +
				'<td>'+data[i].nomor_urut+ '</td>'+
				'<td>'+data[i].tanggal_akta+ '</td>'+
				'<td>'+data[i].jenis_surat+ '</td>'+
				'<td>'+pisahkan(data[i].nama_penghadap, data[i].nama_perusahaan)+'</td>'+
				'<td> <button onclick="ubahLaporanAkta('+data[i].id_daftar_akta+')" class="btn btn-info btn-xs"><span class="lnr lnr-pencil"></span></button>|<button onclick="hapusLaporanAkta('+data[i].id_daftar_akta+')" class="btn btn-danger btn-xs"><span class="lnr lnr-trash"></span></button></td></tr>';
	}
	$('#tampilDataAkta').html(baris);
}

function buatPaging(response){
	  var data_paging = $('#paging_page');
	  var result_page = '';

	  if(response.total_page > 1){
	   result_page += '<ul class="pagination justify-content-center">';

	   if(response.page > (response.prev + 1)){
		result_page += '<li class="page-link"><a href="javascript:showAkta(1)">first</a></li>';
		result_page += '<li class="page-link"><a href="javascript:showAkta('+ (response.page - 1) +')">prev</a></li>';
	   }

	   for(var i=response.start_page; i<=response.display_page; i++){
		if(i == response.page){
		 result_page += '<li class="page-link"><a href="#'+ i +'">'+ i +'</a></li>';
		}else{
		 result_page += '<li class="page-link"><a href="javascript:showAkta('+ i +')">'+ i +'</a></li>';
		}
	   }

	   if(response.total_page > response.display_page){
		result_page += '<li class="page-link"><a href="javascript:showAkta('+ (response.page + 1) +')">next</a></li>';
		result_page += '<li class="page-link"><a href="javascript:showAkta('+ response.total_page +')">last</a></li>';
	   }

	   result_page += '</ul>';
	  }

	  data_paging.html(result_page);
}

function hapusLaporanAkta(id_akta){
	swal({   
			title: "Apakah anda yakin?",   
			text: "Data ini akan dihapus secara permanen!",   
			icon: "warning",   
			dangerMode: true,  
			buttons: true,	
			closeOnClickOutside: false,			
		}).then(function(isConfirm){
			if (isConfirm) { 
				var getUrl = window.location;
				var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
				var request = $.ajax({
					url: baseUrl + "/laporan/hapusLaporanAkta/"+id_akta,
					method: "POST",
					dataType: "JSON"
				});
				
				request.done(function( data ) {
					swal("Berhasil!", "pesan : "+data.pesan, "success");
					location.reload();
				});
			}
		});
			
}

function ubahLaporanAkta(id_akta){
	$('#modalTambahAkta').modal('show');
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var request = $.ajax({
		url: baseUrl + "/laporan/ubahLaporanAkta/"+id_akta,
		method: "POST",
		dataType: "JSON"
	});
	
	request.done(function( data ) {
		
		$('#nomor_bulan').val(data.nomor_bulan);
		$('#nomor_urut').val(data.nomor_urut);
		$('#nomor_akta').val(data.nomor_akta);
		$('#tanggal_akta').val(data.tanggal_akta);
		$('#sifat').val(data.jenis_surat);
		$('#nama_perusahaan').val(data.nama_perusahaan);
		$('.nama_penghadap').val(data.nama_penghadap);
	});
}

function pisahkan(data, perusahaan){
	var view ='';
	var no =0;
	var strSplit = data.split(",");
	for(var i=0; i<strSplit.length - 1; i++){
		view += ++no +'. ' + strSplit[i]+'<br>';
	}
	if(perusahaan == '-' || perusahaan == null){
		view +="-";
	}else{
		view +='<br> 99. ' + perusahaan;
	}
	return view;
}