//tampilDataForm(id_pengumuman);
const formPengumuman = document.querySelector("#formTambahPengumuman"),
		tombolSimpanPengumuman = formPengumuman.querySelector("#submitPengumuman"),
		Pesanerror = formPengumuman.querySelector("#pesan"),
		id_pengumuman = formPengumuman.querySelector("#id_pengumuman");
		var aksi =  $('#formTambahPengumuman').attr("action");
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		formPengumuman.onsubmit = (e)=>{
			e.preventDefault();
		}
		tombolSimpanPengumuman.onclick = ()=>{
			var dataPost = $("#formTambahPengumuman").serialize();
				var request = $.ajax({
					url: aksi,
					method: "POST",
					dataType: "JSON",
					data:dataPost
				});
				
				request.done(function( data ) {
					if(data.status){
						setTimeout(function(){
							swal("Berhasil!", "pesan : "+data.pesan, "success");
							location.reload();
						}, 500);
					}
				});
				
				request.fail(function( jqXHR, textStatus ) {
					swal("Error", "Kesalahan koneksi :"+textStatus, "error"); 
				});
		}
// function tambahData(id_pengumuman){
	// getField(id_pengumuman);
	// $('#modalTambahformPengumuman').modal('show');
// }

function hapus(id_pengumuman){
	swal({   
			title: "Apakah anda yakin?",   
			text: "Data ini akan dihapus secara permanen!",   
			icon: "warning",   
			dangerMode: true,  
			buttons: true,	
			closeOnClickOutside: false,			
		}).then(function(isConfirm){
			if (isConfirm) { 
				var getUrl = window.location;
				var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
				var request = $.ajax({
					url: baseUrl + "/modul/hapusPengumuman/"+id_pengumuman,
					method: "POST",
					dataType: "JSON"
				});
				
				request.done(function( data ) {
					swal("Berhasil!", "pesan : "+data.pesan, "success");
					location.reload();
				});
			}
		});
				
}	

function unggahPersyaratan(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var dataPost = $("#formInput").serialize(); 
	var files = $('#nama_file')[0].files;
	var fd = new FormData();
	fd.append('nama_file',files[0]);
	var request = $.ajax({
		 url:baseUrl + '/modul/unggahFile/1/pengumuman',
		 type:"post",
		 data:fd,
		 contentType: false,
		 processData: false,
		 dataType: 'json',
    });
        
    request.done(function( data ) {
        if(data.status == true){
            swal("Berhasil!", "Status : " +data.pesan, "success");	
			 $('#nama_file_baru').val(data.nama);
			 $("#formFileJadi").show();
			 $("#fileAwal").hide();
        }else{
            swal("Gagal", "Status : " +data.pesan, "error");  
        }
       // window.location.href = baseUrl+$('#linkIndex').val()
    });
        
    request.fail(function( jqXHR, textStatus ) {
        swal("Dibatalkan", "Aksi dibatalkan :) Status : " + textStatus, "error");  
    });
}
// function editData() {
	// $('#ubahDataNotaris').show();
	// $('#dataProfilNotaris').hide();
// }
// function tutup() {
	// $('#ubahDataNotaris').hide();
	// $('#dataProfilNotaris').show();
// }