function gantiImage(id_site, tipe){
	$("#modalUnggahFile").modal('show');
	$("#tipe_input").val(tipe);
	
}
function unggahFile(id_site){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var folder ='';
	var field ='';
		var files = $('#nama_file')[0].files;
		var fd = new FormData();
		fd.append('nama_file',files[0]);
    var tipe = $("#tipe_input").val();
    var tujuan = "/setting/unggahFile/"+id_site+"/" +tipe;
	var request = $.ajax({
		 url:baseUrl + tujuan,
		 type:"post",
		 data:fd,
		 contentType: false,
		 processData: false,
		 dataType: 'json',
    });
	
    request.done(function( data ) {
        if(data.status == true){	
			setTimeout(function(){
				swal("Berhasil!", "pesan : "+data.pesan, "success");
				location.reload();
			}, 500);
        }
        else{
            swal("Gagal", "Status : " +data.pesan, "error");  
        }
       // window.location.href = baseUrl+$('#linkIndex').val()
    });
        
    request.fail(function( jqXHR, textStatus ) {
        swal("Dibatalkan", "Aksi dibatalkan :) Status : " + textStatus, "error");  
    });
}
