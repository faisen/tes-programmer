		const form = document.querySelector("#formTambahLayanan"),
		continueBtn = form.querySelector("#submit"),
		errorText = form.querySelector(".messages-auth");
		
		
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		form.onsubmit = (e)=>{
			e.preventDefault();
		}
		
		continueBtn.onclick = ()=>{
			var dataPost = $("#formTambahLayanan").serialize();
				
				var request = $.ajax({
					url: baseUrl + "/modul/tambah",
					method: "POST",
					dataType: "JSON",
					data:dataPost
				});
				
				request.done(function( data ) {
					if(!data.Error){
						swal({   
							title: "Info!",   
							text: "Status : "+data.pesan,   
							timer: 2000
						});
						location.reload();
						
					}else{
						swal("Dibatalkan", "error saat kirim data", "error"); 
					}
				});
				
				request.fail(function( jqXHR, textStatus ) {
					swal("Error", "Kesalahan koneksi :"+textStatus, "error"); 
				});
		}


function hapusModul(id){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	swal({   
			title: "Apakah anda yakin?",   
			text: "Data ini akan dihapus secara permanen!",   
			icon: "warning",   
			dangerMode: true,  
			buttons: true,	
			closeOnClickOutside: false,			
		}).then(function(isConfirm){
			if (isConfirm) {     
				
				var request = $.ajax({
				  url: baseUrl + "/modul/hapus/"+id,
				  method: "POST",
				  dataType: "JSON"
				});
				 
				request.done(function( data ) {
					if(!data.Error){
						swal("Berhasil!", "Status: "+data.pesan, "success");
						location.reload();
					}
				});
				 
				request.fail(function( jqXHR, textStatus ) {
				  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
				});
			}
		});
}
