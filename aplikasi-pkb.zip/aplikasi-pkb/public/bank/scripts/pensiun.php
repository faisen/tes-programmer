<div class="table-responsive-md">
<h4>Daftar jabatan kosong</h4>
<hr style="height:1px;border:none;color:#079beb;background-color:#079beb;">
<table class="table">
	<thead >
		<tr style="align:center;">
			<th>No</th>
			<th>Kode</th>
			<th>Nama jabatan</th>
		</tr>
	</thead>
	<tbody >
	<?php
	$no=1;
	foreach ($data as $r): ?>
	<tr>
		<td data-field="no"><?= $no++?></td>
		<td data-field="no5"><?= $r->kode_jabatan?></td>
		<td data-field="no2"><?= $r->nama?></td>
	</tr>
	<?php endforeach; ?>
	</tbody>
</table>
</div>