$('#btn-simpan').hide();  
var id_layanan = $('#id_layanan').val();
var id_pengajuan = $('#id_pengajuan_user').val();
bukaSyarat(id_layanan, id_pengajuan);
function bukaSyarat(id_layanan, id_pengajuan){
	
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var request = $.ajax({
        url: baseUrl+'/pengajuan/input/syarat/'+id_layanan+'/'+id_pengajuan,
        method: "GET",
        dataType: "JSON",
		beforeSend: function() {
			$(".loaderMenu").html('<div class="spinner-border text-danger" style="width: 3rem; height:3rem;"role="status"><span class="sr-only">Loading...</span></div>');
		}
	});
	request.done(function( data ) {
		
		var no =1;
        var viewHtml='';
		var path ='';
		if(data.status){
			$("#tampilDataPengajuan").hide();
			$(".spinner-border").remove();
			$("#tampilDataRincian").show();
			for(var i=0; i<data.syarat.length; i++){
				viewHtml +='<tr>'+
				'<td>'+ no++ +'</td>'+
				'<td>'+ data.syarat[i].judul +'</td>'+
				'<td><form id="formUnggahBerkas" method="POST" enctype="multipart/form-data"><input name="nama_file" type="file" class="form-control input-sm" id="nama_file'+data.syarat[i].id_syarat+'" onchange="simpan('+data.syarat[i].id_syarat+','+id_layanan+')" required>'+
				'<input name="id_pengajuan" type="hidden" class="form-control" id="id_pengajuan'+data.syarat[i].id_syarat+'" value="'+data.id_pengajuan+'" required>'+
				'<input name="id_syarat" type="hidden" class="form-control" id="id_syarat'+data.syarat[i].id_syarat+'" value="'+data.syarat[i].id_syarat+'" required><p id="resp'+data.syarat[i].id_syarat+'" style="color:red"></p></form>'+
				'</td>' +
				'</tr>';
			}
			$( "#unggahBerkas" ).html( viewHtml );
			$(".spinner-border").remove();
		}else{
			swal(data.pesan, "Anda tidak diizinkan mendaftarkan dengan jenis layanan yang sama jika proses pengajuan layanan tersebut belum selesai", "error"); 
			$(".spinner-border").remove();
		}
	});
	 
	request.fail(function( jqXHR, textStatus ) {
	  swal("Dibatalkan", "Terjadi kesalahan :)", "error"); 
	  $(".spinner-border").remove();
	});
	
	
}

function batal(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	window.location.href = baseUrl+$('#linkIndex').val();
}

function selesai(){
	var id_pengajuan = $("#id_pengajuan_user").val();
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	window.location.href = baseUrl+'/pengajuan/selesai/'+id_pengajuan;
}

function lihatPengajuan(){
	window.location.reload();
}

function simpan(id_syarat, id_layanan){
	var folder = $('#folder').val();
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var files = $('#nama_file'+id_syarat)[0].files;
	var id_pengajuan = $('#id_pengajuan'+id_syarat).val();
	var id_syarat = $('#id_syarat'+id_syarat).val();
	var fd = new FormData();
	fd.append('nama_file',files[0]);
	fd.append('id_pengajuan',id_pengajuan);
	fd.append('id_syarat',id_syarat);
	var request = $.ajax({
		 url:baseUrl + '/pengajuan/unggahFile/'+id_layanan+'/'+folder,
		 type:"post",
		 data:fd,
		 processData:false,
		 contentType:false,
		 cache:false,
		 async:false,
    });
        
    request.done(function( data ) {
        if(data.status == true){
            swal("Berhasil!", "Status : " +data.pesan, "success");	
			$( '#resp'+id_syarat ).html("terpenuhi");
			//$("#nama_file").remove();
			$('#nama_file'+id_syarat).hide();
        }
        else{
            swal("Gagal", "Status : " +data.pesan, "error");  
        }
       // window.location.href = baseUrl+$('#linkIndex').val()
    });
        
    request.fail(function( jqXHR, textStatus ) {
        swal("Dibatalkan", "Aksi dibatalkan :) Status : " + textStatus, "error");  
    });
}

function getStatus(status){
	if(status == 1){
		return '<label class="badge badge-warning">Menunggu verifikasi</label>';
	}else if(status == 2){
		return '<label class="badge badge-warning">Di verifikasi</label>';
	}
}

function rincian(id) {
	
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
   var request = $.ajax({
	  url: baseUrl + '/pengajuan/rincian/'+id,
	  method: "GET",
	  dataType: "JSON"
	});
	 
	request.done(function( data ) {
		$( "#tampilDataRincian" ).show();
		$( "#tampilDataPengajuan" ).hide();
		var no =1;
        var viewHtml='';
		var path ='';
		for(var i=0; i<data.length; i++){
			path = baseUrl + '/public/file_syarat/' + data[i].nama_file+''
            viewHtml +='<tr>'+
			'<td>'+ no++ +'</td>'+
			'<td>'+ data[i].judul +'</td>'+
			'<td>'+data[i].catatan+ '</td>' +
			'<td><button onclick="openPopup('+"'"+path+"'"+')" class="btn btn-info mr-2 btn-xs">lihat</button>'+
			'<button onclick="verifikasi('+data[i].id_berkas_syarat+','+data[i].id_pengajuan+', 0)" class="btn btn-danger mr-2 btn-xs"> Perbaikan </button></td>' +
			'</tr>';
		}
	    $( "#berkasPengajuan" ).html( viewHtml );
	});
	 
	request.fail(function( jqXHR, textStatus ) {
	  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
	});
	
}

function openPopup(url) {
		popupWindow = window.open(url,'popUpWindow','height=600,width=1000,left=450px,top=200px,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes');
		popUpWindow.onload = function(){
			this.document.title = 'judul';
		}
}

$('#diclaim').click(function(){
	if($(this).prop("checked") == true){
		$('#btn-simpan').show();
	}else{
		$('#btn-simpan').hide();  
	}
});