const formApp = document.querySelector("#FormEdit"),
		btnsave = formApp.querySelector("#submitFormEdit");
		var formAction = $("#FormEdit").attr("action");
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		formApp.onsubmit = (e)=>{
			e.preventDefault();
		}
		
		btnsave.onclick = ()=>{
			var dataPost = $("#FormEdit").serialize();
				var request = $.ajax({
					url: formAction,
					method: "POST",
					dataType: "JSON",
					data:dataPost
				});
				
				request.done(function( data ) {
					if(data.status){
						setTimeout(function(){
							swal("Berhasil!", "pesan : "+data.pesan, "success");
							mundur();
						}, 500);
					}
				});
				
				request.fail(function( jqXHR, textStatus ) {
					swal("Error", "Kesalahan koneksi :"+textStatus, "error"); 
				});
		}

function unggahFilePendukung(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var dataPost = $("#formApp").serialize(); 
	var files = $('#nama_file')[0].files;
	var id_layanan = $('#id_menu_app').val();
	var fd = new FormData();
	fd.append('nama_file',files[0]);
	var request = $.ajax({
		 url:baseUrl + '/setter/unggahFile/1/'+id_layanan,
		 type:"post",
		 data:fd,
		 contentType: false,
		 processData: false,
		 dataType: 'json',
    });
    
    request.done(function( data ) {
        if(data.status == true){
			var path=baseUrl+'/'+data.nama+'';
			var wrapper = $('.tombol');
			var fieldHTML = '<button class="btn btn-danger btn-xs" type="button" onClick="hapusFileLoad()"><span class="lnr lnr-trash"></span></button> | <button type="button" class="btn btn-success btn-xs"  onclick="openNewFile('+"'"+path+"'"+')"><span class="lnr lnr-enter"></span></button>';
			$(wrapper).append(fieldHTML);
            swal("Berhasil!", "Status : " +data.pesan, "success");	
			 $('#nama_file_baru').val(data.nama);
			 $('.btn-file').hide();
			 $(".tampilFilePendukung").show();
			 
        }else{
            swal("Gagal", "Status : " +data.pesan, "error");  
        }
       // window.location.href = baseUrl+$('#linkIndex').val()
    });
        
    request.fail(function( jqXHR, textStatus ) {
        swal("Dibatalkan", "Aksi dibatalkan :) Status : " + textStatus, "error");  
    });
}


function hapusFileLoad(){
	
	$('.btn-file').show();
	$(".tampilFilePendukung").hide();
}
function gantiFileLoad(){
	
	$(".tampilGanti").show();
	$(".tampilFileAsli").hide();
}
function lihatFileAsli(){
	
	$(".tampilGanti").hide();
	$(".tampilFileAsli").show();
}