$('#btn-simpan').hide();  
$('#diclaim').click(function(){
	if($(this).prop("checked") == true){
		$('#btn-simpan').show();
	}else{
		$('#btn-simpan').hide();  
	}
});

var id_pengajuan = $('#id_pengajuan').val();  
var kode_opd = $('#kode_opd').val();  

function tampilkanHasil(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var dataPost = $("#formFilterPengajuan").serialize();
	$.ajax({
		type:'POST',
		url:baseUrl+'/pengajuan/lihat/rincian/0',
		dataType:'HTML',
		data:dataPost,
		success: function(data){
			$('#hasilFilter').html(data);
		}
	});
}

function gantiBerkas(tipe, id_data){
	if(tipe ==11){
		$('#modalGantiBerkas').modal('show');
		$('#id_berkas_syarat').val(id_data);
	}else{
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		var files = $('#nama_file')[0].files;
		var fd = new FormData();
		fd.append('nama_file',files[0]);
		var request = $.ajax({
			 url:baseUrl + '/modul/unggahFile/1/verif_tpp',
			 type:"post",
			 data:fd,
			 contentType: false,
			 processData: false,
			 dataType: 'json',
		});
			
		request.done(function( data ) {
			if(data.status == true){
				swal("Berhasil!", "Status : " +data.pesan, "success");	
				 $('#berkas_baru').val(data.nama);
				 $('#pesanFile').html("Unggah berhasil:" + data.nama);
				 $("#nama_file").remove();
			}else{
				swal("Gagal", "Status : " +data.pesan, "error");  
			}
		   // window.location.href = baseUrl+$('#linkIndex').val()
		});
			
	}
}

function update(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
  
	var dataPost = $('#formGantiBerkas').serialize();
	var request = $.ajax({
	  url: baseUrl + "/pengajuan/gantiBerkas/",
	  method: "POST",
	  data: dataPost,
	  dataType: "JSON"
	});
	 
	request.done(function( data ) {
		if(!data.Error){
			swal("Berhasil!", "Status: "+data.pesan, "success");
			location.reload();
		}
	});
	 
	request.fail(function( jqXHR, textStatus ) {
	  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
	});
}

function ajukanUlang(id_pengajuan){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var request = $.ajax({
	  url: baseUrl + "/pengajuan/edit/"+id_pengajuan,
	  method: "POST",
	  dataType: "JSON"
	});
	 
	request.done(function( data ) {
		if(!data.Error){
			swal("Berhasil!", "Status: "+data.pesan, "success");
			location.reload();
		}
	});
	 
	request.fail(function( jqXHR, textStatus ) {
	  swal("Dibatalkan", "Aksi dibatalkan :)", "error"); 
	});
}

function getStatusBerkas(sts){
	if(sts == 1){
		return '<span class="label label-success">OK</span>';
	}else{
		return '<span class="label label-danger">Ditolak</span>';
	}
}
