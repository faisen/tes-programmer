hitung();
const formNotaris = document.querySelector(".formUpdateNotaris"),
		tombolSimpan = formNotaris.querySelector("#submitDataNotaris"),
		Pesanerror = formNotaris.querySelector("#pesan");
		let tomboledit = document.querySelector("#tombolEdit");
		
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		formNotaris.onsubmit = (e)=>{
			e.preventDefault();
		}
		
		tombolSimpan.onclick = ()=>{
			var dataPost = $(".formUpdateNotaris").serialize();
				var request = $.ajax({
					url: baseUrl + "/pengguna/updateNotaris",
					method: "POST",
					dataType: "JSON",
					data:dataPost
				});
				
				request.done(function( data ) {
					if(data.status){
						setTimeout(function(){
							swal("Berhasil!", "pesan : "+data.pesan, "success");
							location.reload();
						}, 500);
					}
				});
				
				request.fail(function( jqXHR, textStatus ) {
					swal("Error", "Kesalahan koneksi :"+textStatus, "error"); 
				});
		}

function hitung(){
	// var request = $.ajax({
		// url: baseUrl + "/pengguna/updateNotaris",
		// method: "POST",
		// dataType: "JSON",
		// data:dataPost
	// });
	
	// request.done(function( data ) {
		
	// });
	$('#jumlahAkta').html('400 <span>Daftar Akta</span>');
	$('#jumlahDaftarProtes').html('400 <span>Daftar Protes</span>');
	$('#jumlahDibukukan').html('2174 <span>Surat dibukukan</span>');
	$('#jumlahDisahkan').html('2174 <span>Surat disahkan</span>');
}	

function editData() {
	$('#ubahDataNotaris').show();
	$('#dataProfilNotaris').hide();
}

function showFormNotaris() {
	$('#showFormNotaris').modal('show');
}

function tambahDataNotaris() {
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		
	var dataPost = $(".formTambahDataNotaris").serialize();
	var request = $.ajax({
		url: baseUrl + "/pengguna/updateNotaris/0",
		method: "POST",
		dataType: "JSON",
		data:dataPost
	});
	
	request.done(function( data ) {
		if(data.status){
			setTimeout(function(){
				swal("Berhasil!", "pesan : "+data.pesan, "success");
				location.reload();
			}, 500);
		}
	});
}
function tutup() {
	$('#ubahDataNotaris').hide();
	$('#dataProfilNotaris').show();
}

// pegawai

function showFormPegawai() {
	$('#showFormPegawai').modal('show');
}
function tutupForm() {
	$('#showFormPegawai').modal('hide');
}

function tambahDataPegawai() {
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		
	var dataPost = $(".formTambahDataPegawai").serialize();
	var request = $.ajax({
		url: baseUrl + "/pengguna/tambahPegawai",
		method: "POST",
		dataType: "JSON",
		data:dataPost
	});
	
	request.done(function( data ) {
		if(data.status){
			setTimeout(function(){
				swal("Berhasil!", "pesan : "+data.pesan, "success");
				location.reload();
			}, 500);
		}
	});
	request.fail(function( jqXHR, textStatus ) {
		swal("Error", "Kesalahan saat tambah data :"+textStatus, "error"); 
	});
}

function hapusDataPegawai(id) {
	swal({   
			title: "Apakah anda yakin?",   
			text: "Data ini akan dihapus secara permanen!",   
			icon: "warning",   
			dangerMode: true,  
			buttons: true,	
			closeOnClickOutside: false,			
		}).then(function(isConfirm){
			if (isConfirm) {
				var getUrl = window.location;
				var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

				var request = $.ajax({
					url: baseUrl + "/pengguna/hapusPegawai/" + id,
					method: "POST",
					dataType: "JSON",
				});

				request.done(function( data ) {
					if(data.status){
						setTimeout(function(){
							swal("Berhasil!", "pesan : "+data.pesan, "success");
							location.reload();
						}, 500);
					}
				});
				request.fail(function( jqXHR, textStatus ) {
					swal("Error", "Kesalahan saat tambah data :"+textStatus, "error"); 
				});
			}
		});
}

function buatAkunPegawai(){
	var nama = $('#nama').val();
	if(nama.length < 3){
		swal("Gagal!", "Nama tidak boleh kurang dari 3 huruf", "error");
	}else{
		var username = nama + "_" + makeid(3);
		var password = nama + "_" + makeid(5);
		$("#username").val(username);
		$("#password").val(password);
	}
}

function makeid(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   return result;
}


function unggahFile(tipe){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var folder ='';
	var field ='';
	if(tipe == 11){
		var files = $('#nama_file')[0].files;
		var fd = new FormData();
		fd.append('nama_file',files[0]);
		folder = "dokumen";
		field = "file_sk";
	}else{
		var files = $('#file_foto')[0].files;
		var fd = new FormData();
		fd.append('nama_file',files[0]);
		folder="foto";
		field = "foto";
	}
    var id_notaris = $("#id_notaris").val();
    var tujuan = "/pengguna/unggahFile/"+id_notaris+"/" +folder+"/"+field;
	var request = $.ajax({
		 url:baseUrl + tujuan,
		 type:"post",
		 data:fd,
		 contentType: false,
		 processData: false,
		 dataType: 'json',
    });
	
    request.done(function( data ) {
        if(data.status == true){	
			setTimeout(function(){
				swal("Berhasil!", "pesan : "+data.pesan, "success");
				location.reload();
			}, 500);
        }
        else{
            swal("Gagal", "Status : " +data.pesan, "error");  
        }
       // window.location.href = baseUrl+$('#linkIndex').val()
    });
        
    request.fail(function( jqXHR, textStatus ) {
        swal("Dibatalkan", "Aksi dibatalkan :) Status : " + textStatus, "error");  
    });
}

function showJamKerja(id_notaris){
	var id_layanan = $('#id_layanan').val();
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	$.ajax({
		type:'GET',
		url:baseUrl+'/pengguna/getJamKerjaNotaris/'+id_notaris,
		dataType:'JSON',
		success: function(data){
			var baris='';
			var no=0;
			for(var i=0; i<data.length; i++){
				baris +='<tr><td>'+data[i].buka+ '</td>' +
						'<td>'+data[i].tutup+ '</td></tr>';
			}
			$('#jamKerja').show();
			$('#tombolTutupJamKerja').show();
			$('#tampilJamKerja').html(baris);
		}
	});
	
}

function showKaryawan(id_notaris){
	var id_layanan = $('#id_layanan').val();
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	$.ajax({
		type:'GET',
		url:baseUrl+'/pengguna/getKaryawanNotaris/'+id_notaris,
		dataType:'JSON',
		success: function(data){
			var baris='';
			var no=0;
			for(var i=0; i<data.length; i++){
				baris +='<tr><td>'+data[i].nama+ '</td>' +
						'<td>'+data[i].jabatan+ '</td></tr>';
			}
			$('#karyawan').show();
			$('#tombolTutupKaryawan').show();
			$('#tampilKaryawan').html(baris);
		}
	});
}
function tutupModul(tipe){
	if(tipe == 2){
		$('#karyawan').hide();
		$('#tombolTutupKaryawan').hide();
	}else if(tipe == 1){
		$('#jamKerja').hide();
		$('#tombolTutupJamKerja').hide();
	}else{
		return false;
	}
}
